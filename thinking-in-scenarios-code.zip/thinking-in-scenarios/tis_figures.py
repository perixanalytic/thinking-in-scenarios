"""
tis_figures.py — the figure kit for *Thinking in Scenarios*.

Every chart in the book is one function here. Each draws from tis_core.py, so a
changed assumption redraws every picture that depends on it.

Design rules (Appendix L):
  1. The title states the decision insight, not the chart type.
  2. Option colours are fixed for the whole book: A blue, B orange, C aqua.
  3. A dashed line is always a straitjacket (an option priced without its decision);
     the solid line of the same colour is the same option priced as a strategy.
  4. Scenario colours are fixed: Tailwind yellow, Middle violet, Squeeze red.
  5. Decision thresholds are drawn as thin dark rules and labelled in words.
  6. Large areas use tints; saturated colour is reserved for marks and lines.
  7. Every figure carries its source line: the lab and the seed.

Usage:  python tis_figures.py            # writes every figure to ./figs
        from tis_figures import fig_fan; fig_fan().savefig("fan.png")
"""
from __future__ import annotations

import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
from matplotlib.patches import FancyBboxPatch, Polygon
from matplotlib.colors import ListedColormap, to_rgb
from scipy.stats import binom
import logging
from matplotlib import font_manager

logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)
_installed = {f.name for f in font_manager.fontManager.ttflist}
FONT = next((f for f in ("Inter", "Helvetica Neue", "Helvetica", "Arial", "Segoe UI") if f in _installed), "DejaVu Sans")

import tis_core as core

# ---------------------------------------------------------------------------
# Style
# ---------------------------------------------------------------------------
INK, INK2, MUTED, GRID, SURF = "#0b0b0b", "#52514e", "#8a8984", "#e6e5e1", "#ffffff"
OPT = {"A": "#2a78d6", "B": "#eb6834", "C": "#1baf7a"}
OPT_NAME = {"A": "A  Full entry", "B": "B  Staged", "C": "C  Defer"}
SCN = {"Tailwind": "#eda100", "Middle": "#6250d6", "Squeeze": "#e34948"}
S = 0.80          # layout scale: figures are drawn at 80% size with full-size type, so text reads larger on e-readers
BLUES = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]

plt.rcParams.update({
    "font.family": FONT, "font.size": 8.5, "axes.titlesize": 11, "axes.labelsize": 8.5,
    "axes.edgecolor": GRID, "axes.labelcolor": INK2, "axes.linewidth": 0.8,
    "xtick.color": INK2, "ytick.color": INK2, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "xtick.major.size": 0, "ytick.major.size": 0, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.6, "axes.axisbelow": True, "axes.spines.top": False,
    "axes.spines.right": False, "legend.frameon": False, "legend.fontsize": 8,
    "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
    "lines.linewidth": 2.0, "lines.solid_capstyle": "round",
})


def tint(hex_, a=0.22):
    r, g, b = to_rgb(hex_)
    return (1 - a + a * r, 1 - a + a * g, 1 - a + a * b)


def frame(title, subtitle, w=7.2, h=4.0, ncols=1, nrows=1, source="", **kw):
    """Figure with a decision-title and subtitle that wrap to the figure width."""
    import textwrap
    W, H = w * S, h * S
    t_lines = textwrap.wrap(title, int(W * 13.0)) or [""]
    s_lines = textwrap.wrap(subtitle, int(W * 16.0)) if subtitle else []
    head_in = 0.16 + 0.24 * len(t_lines) + 0.19 * len(s_lines)
    H += max(0, head_in - 0.55)                         # grow the canvas instead of squeezing the plot
    fig, axes = plt.subplots(nrows, ncols, figsize=(W, H), **kw)
    fig.text(0.1 / W, 1 - 0.08 / H, "\n".join(t_lines), ha="left", va="top", fontsize=11.5, fontweight="semibold", color=INK, linespacing=1.15)
    if s_lines:
        fig.text(0.1 / W, 1 - (0.12 + 0.24 * len(t_lines)) / H, "\n".join(s_lines), ha="left", va="top", fontsize=8.8, color=INK2, linespacing=1.25)
    if source:
        fig.text(0.1 / W, 0.04 / H, source, ha="left", va="bottom", fontsize=7, color=MUTED)
    fig._head_in = head_in + 0.12
    return fig, axes


def finish(fig, top=0.80, bottom=0.15, left=0.08, right=0.98, panel_titles=None, **kw):
    """Margins are given as fractions of the original 7.2-inch design and applied in inches."""
    W, H = fig.get_size_inches()
    Wo = W / S
    head = getattr(fig, "_head_in", (1 - top) * H)
    if panel_titles is None:
        panel_titles = any(ax.get_title(loc="left") for ax in fig.axes)
    head += 0.26 if panel_titles else 0.0
    bottom_in = max(0.62, bottom * 4.0)                 # x-label, ticks and the source line
    left_in = max(0.62, left * Wo)
    right_in = max(0.18, (1 - right) * Wo)
    fig.subplots_adjust(top=1 - head / H, bottom=bottom_in / H, left=left_in / W, right=1 - right_in / W, **kw)
    return fig


def label(ax, x, y, text, color=INK, ha="left", va="center", size=8, weight="normal", **kw):
    ax.text(x, y, text, color=color, ha=ha, va=va, fontsize=size, fontweight=weight, **kw)


def rule(ax, x=None, y=None, text=None, where=0.97, color=INK2, ha="left", lw=0.9):
    if x is not None:
        ax.axvline(x, color=color, lw=lw, zorder=3)
        if text:
            ax.text(x, where, " " + text, transform=ax.get_xaxis_transform(), color=color,
                    fontsize=7.6, ha=ha, va="top")
    if y is not None:
        ax.axhline(y, color=color, lw=lw, zorder=3)
        if text:
            ax.text(where, y, text + " ", transform=ax.get_yaxis_transform(), color=color,
                    fontsize=7.6, ha="right", va="bottom")


# ---------------------------------------------------------------------------
# Prologue
# ---------------------------------------------------------------------------
def fig_native_simulator():
    rows = [
        ("Simulates stories, not choices", "Imagines what will happen; rarely lists what it could do.",
         "1  DEFINE", "Decision Brief", "Options, owner, objectives on one page"),
        ("Treats vivid detail as evidence", "Cannot tell a remembered fact from an imagined one.",
         "2  EVIDENCE", "Evidence Ledger", "Every input typed: known / believed / assumed"),
        ("Moves one lever, ignores feedback", "Runs ceteris paribus; loops and thresholds vanish.",
         "3  MODEL", "Assumption Register", "Claims typed; loops drawn; sanity-tested"),
        ("Runs the single most plausible future", "Plans the typical path; the tails go unimagined.",
         "4  FUTURES", "Scenario Set + fan", "Structurally different worlds; a distribution"),
        ("Scores futures by how they feel", "Fear and hope set the weights, unspoken.",
         "5  EVALUATE", "Scorecard + tree", "Weights stated; strategies priced; regret explicit"),
        ("Rewrites its own history", "Hindsight edits what we believed at the time.",
         "6  LEARN", "Record + signposts", "Beliefs frozen; tripwires pre-committed; scored"),
    ]
    fig = plt.figure(figsize=(7.2, 5.6))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")
    ax.text(1.5, 98, "The method is the brain's scenario engine, given a memory and a referee",
            fontsize=11.5, fontweight="semibold", va="top", color=INK)
    ax.text(1.5, 93.6, "Six defaults of native mental simulation (left), and the stage and artefact that discipline each (right)",
            fontsize=8.8, va="top", color=INK2)
    ax.text(2, 87.5, "THE NATIVE SIMULATOR — what it does by default", fontsize=7.6, fontweight="bold", color=MUTED)
    ax.text(56, 87.5, "THE DISCIPLINED SIMULATOR — what the method adds", fontsize=7.6, fontweight="bold", color=MUTED)
    y0, hgt, gap = 84, 11.2, 2.4
    for i, (d, dsub, stage, art, asub) in enumerate(rows):
        y = y0 - i * (hgt + gap)
        ax.add_patch(FancyBboxPatch((2, y - hgt), 44, hgt, boxstyle="round,pad=0,rounding_size=1.2",
                                    fc="#f6f5f2", ec="none"))
        ax.text(4, y - 3.4, d, fontsize=9, fontweight="semibold", color=INK, va="center")
        ax.text(4, y - 7.6, dsub, fontsize=7.8, color=INK2, va="center")
        ax.annotate("", xy=(55, y - hgt / 2), xytext=(47.5, y - hgt / 2),
                    arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=1.1))
        ax.add_patch(FancyBboxPatch((56, y - hgt), 42, hgt, boxstyle="round,pad=0,rounding_size=1.2",
                                    fc=tint(OPT["A"], 0.12), ec="none"))
        ax.text(58, y - 3.4, stage, fontsize=7.6, fontweight="bold", color=OPT["A"], va="center")
        ax.text(72, y - 3.4, art, fontsize=9, fontweight="semibold", color=INK, va="center")
        ax.text(58, y - 7.6, asub, fontsize=7.8, color=INK2, va="center")
    ax.text(1.5, 1.2, "Sources for the defaults: Craik 1943; Kahneman & Tversky 1982; Fischhoff 1975; Sterman 1989; "
            "Gilbert & Wilson 2007; Schacter, Addis & Buckner 2007.", fontsize=6.8, color=MUTED)
    return fig


def fig_method_map():
    """Figure 0.1 — the six-stage loop, its artefacts, and the seven links of the audit."""
    from matplotlib.patches import FancyArrowPatch
    stages = [("1  DEFINE", "Part I", "Decision Brief", "1 Frame"),
              ("2  EVIDENCE", "Part II", "Evidence Ledger", "2 Evidence"),
              ("3  MODEL", "Part III", "Assumption Register", "3 Model"),
              ("4  FUTURES", "Part IV", "Scenario Set · fan · map", "4 Futures"),
              ("5  EVALUATE", "Parts V–VI", "Scorecard · tree · game", "5 Options · 6 Judgment"),
              ("6  ACT & LEARN", "Part VII", "Record · signposts · audit", "7 Learning")]
    pos = [(4, 58), (36, 58), (68, 58), (68, 18), (36, 18), (4, 18)]     # a loop: across, down, back
    fig = plt.figure(figsize=(7.2, 4.5))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 100); ax.set_ylim(10, 100); ax.axis("off")
    ax.text(1.5, 97.5, "The method is one loop, and every stage leaves an artefact", fontsize=12.5, fontweight="semibold", va="top", color=INK)
    ax.text(1.5, 91.5, "Stages and parts (top line), the artefact each produces, and the link of the Decision Quality Audit that scores it",
            fontsize=8.8, va="top", color=INK2)
    w, h = 28, 26
    for (title, part, art, link), (x, y) in zip(stages, pos):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.6", fc=tint(OPT["A"], 0.10), ec=OPT["A"], lw=1.2))
        ax.text(x + 2, y + h - 3.5, title, fontsize=9.6, fontweight="bold", color=OPT["A"], va="top")
        ax.text(x + w - 2, y + h - 3.6, part, fontsize=7.8, color=INK2, va="top", ha="right")
        ax.text(x + 2, y + h - 11.5, art, fontsize=9.0, color=INK, va="top", fontweight="semibold")
        ax.text(x + 2, y + 3.0, "audit link " + link, fontsize=7.6, color=INK2, va="bottom")
    arrow = dict(arrowstyle="-|>", color=INK2, lw=1.3, mutation_scale=12)
    for (x1, y1), (x2, y2) in ((pos[0], pos[1]), (pos[1], pos[2])):
        ax.add_patch(FancyArrowPatch((x1 + w + 0.6, y1 + h / 2), (x2 - 0.6, y2 + h / 2), **arrow))
    ax.add_patch(FancyArrowPatch((pos[2][0] + w / 2, pos[2][1] - 0.6), (pos[3][0] + w / 2, pos[3][1] + h + 0.6), **arrow))
    for (x1, y1), (x2, y2) in ((pos[3], pos[4]), (pos[4], pos[5])):
        ax.add_patch(FancyArrowPatch((x1 - 0.6, y1 + h / 2), (x2 + w + 0.6, y2 + h / 2), **arrow))
    ax.add_patch(FancyArrowPatch((pos[5][0] + w / 2, pos[5][1] + h + 0.6), (pos[0][0] + w / 2, pos[0][1] - 0.6),
                                 arrowstyle="-|>", color=SCN["Squeeze"], lw=1.6, mutation_scale=12))
    ax.text(pos[0][0] + w / 2 + 1.5, 50.5, "the loop runs backward too:\nmonitoring reopens evidence,\nmodel failure reopens structure,\nnew objectives reopen the frame",
            fontsize=7.6, color=SCN["Squeeze"], va="center", ha="left")
    ax.text(1.5, 12.0, "What Makes This Book Different · the method as a map", fontsize=7, color=MUTED)
    return fig


def fig_plan_vs_world():
    totals, plan = core.plan_vs_world()
    p_on = (totals <= plan).mean(); p80 = np.percentile(totals, 80); mean = totals.mean()
    fig, ax = frame("The plan is the one future that almost never happens",
                    "Pilot-city launch: eight tasks, each imagined going 'typically'. 100,000 simulated launches.",
                    h=3.9, source="Lab 0 · tis_core.plan_vs_world · seed 7")
    bins = np.arange(10, 70, 1)
    hist, edges = np.histogram(totals, bins=bins)
    hist = hist / hist.sum()
    centers = (edges[:-1] + edges[1:]) / 2
    ax.bar(centers, hist, width=0.82, color=[tint(OPT["A"], 0.5) if c <= plan else tint(OPT["B"], 0.5) for c in centers],
           edgecolor="none")
    ax.axvline(plan, color=INK, lw=0.9)
    ax.text(plan + 0.6, 0.99, f"The plan: {plan:.0f} weeks (sum of typical durations)", transform=ax.get_xaxis_transform(), fontsize=7.6, va="top")
    ax.set_ylim(0, 0.062)
    ax.axvline(p80, color=INK2, lw=0.9)
    ax.text(p80, 0.62, f" 80% confidence: {p80:.0f} weeks", transform=ax.get_xaxis_transform(), fontsize=7.6, color=INK2, va="top")
    ax.text(plan - 0.6, 0.93, f"On time\n{p_on:.0%}", transform=ax.get_xaxis_transform(), ha="right", va="top", fontsize=9,
            fontweight="semibold", color=OPT["A"])
    ax.text(plan + 6.5, 0.86, f"Late\n{1 - p_on:.0%}", transform=ax.get_xaxis_transform(), ha="left", va="top", fontsize=9,
            fontweight="semibold", color=OPT["B"])
    ax.set_xlim(12, 62); ax.set_xlabel("Weeks to first shipment"); ax.set_ylabel("Share of simulated launches")
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0))
    ax.text(0.99, 0.30, f"Mean outcome {mean:.1f} weeks", transform=ax.transAxes, ha="right", fontsize=7.8, color=INK2)
    return finish(fig, top=0.80)


# ---------------------------------------------------------------------------
# Part I
# ---------------------------------------------------------------------------
def fig_process_luck():
    fig, (a1, a2) = frame("Luck owns any single decision; process owns a career",
                          "Two cohorts of 200 managers. Good process wins each bet with p = 0.60, bad process with p = 0.40.",
                          ncols=2, h=3.9, source="Lab 1 · seed 11 (left); exact binomial (right)",
                          gridspec_kw=dict(width_ratios=[1, 1.15], wspace=0.28))
    def cohort(p, n=200, t=50, seed=11):
        r = np.random.default_rng(seed)
        return 2 * (r.random((n, t)) < p).sum(axis=1) - t
    good, bad = cohort(0.60), cohort(0.40)
    bins = np.arange(-36, 38, 4)
    a1.hist(bad, bins=bins, color=tint(OPT["B"], 0.9), edgecolor=SURF, linewidth=1.5, label="Bad process")
    a1.hist(good, bins=bins, color=tint(OPT["A"], 0.75), edgecolor=SURF, linewidth=1.5, label="Good process", alpha=0.95)
    a1.axvline(0, color=INK2, lw=0.9)
    a1.set_xlabel("Net result after 50 bets"); a1.set_ylabel("Managers")
    a1.set_ylim(0, 68)
    a1.text(9, 67, f"{(bad > 0).sum()} bad-process\nmanagers\nended ahead", fontsize=7.6, color=OPT["B"], fontweight="semibold", va="top", ha="left")
    a1.legend(loc="upper left", handlelength=1, fontsize=7.0)
    a1.set_title("After 50 bets", loc="left", fontsize=9, color=INK, pad=4)
    t = np.unique(np.round(np.logspace(0, np.log10(501), 90)).astype(int)); t = t[t % 2 == 1]
    p_bad_ahead = 1 - binom.cdf(np.floor(t / 2), t, 0.40)
    a2.plot(t, p_bad_ahead, color=OPT["B"], label="P(a bad-process manager is ahead)")
    for x in (5, 51, 201):
        y = 1 - binom.cdf(np.floor(x / 2), x, 0.40)
        a2.plot(x, y, "o", color=OPT["B"], ms=6, mec=SURF, mew=1.5)
        a2.text(x * (0.85 if x > 100 else 1.12), y + 0.025, f"{y:.0%} after {x}", fontsize=7.4, color=INK, ha="right" if x > 100 else "left")
    a2.set_xscale("log"); a2.set_xlabel("Number of decisions judged (log scale)")
    a2.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0))
    a2.set_ylim(0, 0.5)
    a2.text(0.98, 0.97, "Odd numbers of bets (no ties);\nequals P(good process is behind).", transform=a2.transAxes, ha="right", va="top", fontsize=7.0, color=INK2)
    a2.set_title("Chance the scoreboard lies", loc="left", fontsize=9, color=INK, pad=4)
    return finish(fig, top=0.76, left=0.07, bottom=0.16)


def fig_fan():
    v = core.mc_independent(); st = core.fan_stats(v)
    fig, ax = frame("Replace the number with the distribution",
                    "Full-entry NPV ($M), 100,000 draws of market, share and margin. The point forecast 3.92 hides the shape.",
                    h=3.9, source="Lab 6 · tis_core.mc_independent · seed 2026")
    bins = np.arange(-25, 40, 1)
    h, e = np.histogram(v, bins=bins); h = h / h.sum(); c = (e[:-1] + e[1:]) / 2
    cols = [tint(SCN["Squeeze"], 0.75) if x < 0 else tint(OPT["A"], 0.75) for x in c]
    ax.bar(c, h, width=0.85, color=cols, edgecolor="none")
    ymax = h.max() * 1.25; ax.set_ylim(0, ymax)
    for q, nm in ((st["p5"], "P5"), (st["median"], "Median"), (st["p95"], "P95")):
        ax.plot([q, q], [0, ymax * 0.80], color=INK2, lw=0.9)
        ax.text(q, ymax * 0.82, f"{nm}\n{q:+.1f}", ha="center", va="bottom", fontsize=7.6, color=INK2)
    ax.plot([3.92], [ymax * 0.06], marker="v", color=INK, ms=7)
    ax.text(4.5, ymax * 0.10, "Middle-path\npoint forecast 3.92", fontsize=7.4, color=INK, va="bottom")
    ax.text(-24, ymax * 0.55, f"Loss\n{st['p_loss']:.1%} of futures", color=SCN["Squeeze"], fontsize=9.5, fontweight="semibold")
    ax.text(25, ymax * 0.55, f"Mean {st['mean']:.2f}\nSD {st['sd']:.2f}", color=OPT["A"], fontsize=9.5, fontweight="semibold")
    ax.set_xlabel("Five-year NPV of full entry, $M"); ax.set_ylabel("Share of simulated futures")
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=1))
    return finish(fig, top=0.80)


# ---------------------------------------------------------------------------
# Part II
# ---------------------------------------------------------------------------
SIMPSON = {  # incumbent share and volume by district type and segment (corrected Lab 2)
    ("low", "premium"): (0.15, 10), ("low", "standard"): (0.45, 90),
    ("high", "premium"): (0.20, 70), ("high", "standard"): (0.50, 30),
}


def fig_simpson():
    fig, ax = frame("The aggregate says the opposite of every segment",
                    "Incumbent's share by district income: within each segment (lines) and pooled across segments (bars).",
                    h=3.9, source="Lab 2 · data entered in the listing")
    agg = {}
    for d in ("low", "high"):
        vol = sum(SIMPSON[(d, s)][1] for s in ("premium", "standard"))
        agg[d] = sum(SIMPSON[(d, s)][0] * SIMPSON[(d, s)][1] for s in ("premium", "standard")) / vol
    xs = {"low": 0, "high": 1}
    ax.bar([0, 1], [agg["low"], agg["high"]], width=0.5, color=tint(INK2, 0.18), edgecolor="none", zorder=1)
    for d in ("low", "high"):
        ax.text(xs[d], 0.02, f"All segments pooled\n{agg[d]:.2f}", ha="center", va="bottom", fontsize=8, color=INK, fontweight="semibold")
    for seg, col in (("standard", OPT["A"]), ("premium", OPT["B"])):
        ys = [SIMPSON[("low", seg)][0], SIMPSON[("high", seg)][0]]
        ax.plot([0, 1], ys, color=col, marker="o", ms=7, mec=SURF, mew=2, zorder=4, label=f"{seg.title()} segment")
        ax.text(1.06, ys[1], f"{seg.title()}  {ys[0]:.2f} → {ys[1]:.2f}", color=INK, fontsize=8, va="center")
    ax.set_xticks([0, 1], ["Low-income districts\n(90% of volume is standard)", "High-income districts\n(70% of volume is premium)"])
    ax.set_xlim(-0.45, 1.75); ax.set_ylim(0, 0.62); ax.set_ylabel("Incumbent's market share")
    ax.legend(loc="upper left", fontsize=7.6)
    ax.grid(axis="x", visible=False)
    return finish(fig, top=0.80, bottom=0.17)


def fig_bayes():
    xs = np.linspace(0.02, 0.16, 600)
    fig, (a1, a2) = frame("One pilot number, three worlds: what 7.8% is entitled to change",
                          "Left: how likely each observation is under each scenario. Right: the posterior for every possible observation.",
                          ncols=2, h=4.0, source="Lab 3 · Gaussian likelihood, σ = 1.5 pp · prior 25/50/25",
                          gridspec_kw=dict(wspace=0.25))
    for i, nm in enumerate(core.SCEN_NAMES):
        y = np.exp(-0.5 * ((xs - core.PILOT_MUS[i]) / core.SIGMA) ** 2)
        a1.plot(xs * 100, y, color=SCN[nm])
        a1.text(core.PILOT_MUS[i] * 100 + (0.5 if nm == "Middle" else 0), 1.04, nm, color=INK, ha="center", fontsize=8)
    a1.axvline(7.8, color=INK, lw=0.9); a1.text(7.9, 1.24, "observed 7.8%", fontsize=7.6, color=INK, va="center")
    a1.set_ylim(0, 1.34); a1.set_yticks([0, 0.25, 0.5, 0.75, 1.0]); a1.set_xlabel("Pilot-city share, %"); a1.set_ylabel("Relative likelihood")
    a1.set_title("Likelihoods", loc="left", fontsize=9, pad=4)
    post = core.posterior(xs)
    a2.stackplot(xs * 100, post[:, 2], post[:, 1], post[:, 0], colors=[tint(SCN["Squeeze"], .7), tint(SCN["Middle"], .55), tint(SCN["Tailwind"], .75)],
                 edgecolor=SURF, linewidth=1.5)
    a2.axvline(7.8, color=INK, lw=0.9)
    p = core.posterior(0.078)[0]
    a2.text(8.0, 0.86, f"At 7.8%:\nTailwind {p[0]:.3f}\nMiddle {p[1]:.3f}\nSqueeze {p[2]:.3f}", fontsize=7.6, color=INK, va="center",
            bbox=dict(fc=SURF, ec="none", pad=1.5))
    a2.text(3.0, 0.5, "Squeeze", color=INK, fontsize=8, ha="left"); a2.text(10.1, 0.30, "Middle", color=INK, fontsize=8)
    a2.text(14.2, 0.5, "Tail-\nwind", color=INK, fontsize=8, ha="center")
    a2.set_xlim(2, 16); a2.set_ylim(0, 1); a2.set_xlabel("Pilot-city share, %"); a2.set_ylabel("Posterior probability")
    a2.set_title("Posterior by observation", loc="left", fontsize=9, pad=4)
    return finish(fig, top=0.78, left=0.07, bottom=0.16)


def fig_uplift():
    w = core.voucher_world(); tc = core.targeting_curves(w)
    naive = w["y_hist"][w["t_hist"]].mean() - w["y_hist"][~w["t_hist"]].mean()
    rct = w["y_rct"][w["t_rct"]].mean() - w["y_rct"][~w["t_rct"]].mean()
    fig, (a1, a2) = frame("Predicting who buys is not knowing who buys because of you",
                          "Tasting-voucher decision, 40,000 home-market shoppers. Left: effect estimates. Right: profit by targeting rule.",
                          ncols=2, h=4.0, source="Lab 2A · tis_core.voucher_world · seed 21",
                          gridspec_kw=dict(width_ratios=[0.8, 1.2], wspace=0.32))
    vals = [naive, rct, w["tau"].mean()]
    names = ["Targeted\nhistory", "Randomised\ntest", "True\neffect"]
    cols = [OPT["B"], OPT["A"], INK2]
    a1.bar(range(3), vals, color=[tint(c, 0.8) for c in cols], width=0.62, edgecolor="none")
    for i, v in enumerate(vals):
        a1.text(i, v + 0.006, f"+{v * 100:.1f} pts", ha="center", fontsize=8, fontweight="semibold", color=INK)
    a1.set_xticks(range(3), names, fontsize=7.4); a1.set_ylabel("Lift in purchase rate"); a1.set_ylim(0, 0.33)
    a1.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0)); a1.grid(axis="x", visible=False)
    a1.set_title("How big is the voucher effect?", loc="left", fontsize=9, pad=4)
    f = tc["frac"] * 100
    a2.plot(f, tc["by_uplift"] * 1000, color=OPT["A"], label="Rank by measured uplift")
    a2.plot(f, tc["by_propensity"] * 1000, color=OPT["B"], label="Rank by predicted purchase")
    a2.plot(f, tc["random"] * 1000, color=MUTED, lw=1.2, label="Treat at random")
    a2.axhline(0, color=INK2, lw=0.8)
    k = int(np.argmax(tc["by_uplift"]))
    a2.plot(f[k], tc["by_uplift"][k] * 1000, "o", color=OPT["A"], ms=7, mec=SURF, mew=2)
    a2.annotate(f"Best: treat {f[k]:.0f}%\n+{tc['by_uplift'][k] * 1000:.0f} per 1,000\nshoppers", xy=(f[k], tc["by_uplift"][k] * 1000), xytext=(46, 38), ha="left", fontsize=7.4, color=INK,
                arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.8))
    a2.set_xlabel("Share of shoppers given a voucher, %"); a2.set_ylabel("Incremental profit per 1,000 shoppers")
    a2.legend(loc="lower right", fontsize=7.4)
    a2.set_title("Whom should we treat?", loc="left", fontsize=9, pad=4)
    return finish(fig, top=0.78, bottom=0.17, left=0.08)


# ---------------------------------------------------------------------------
# Part III
# ---------------------------------------------------------------------------
def fig_model_changelog():
    steps = [("v1.0 Jan\ninitial model", 4.92, "abs"), ("v1.1 Feb\noff-by-one fixed", -1.00, "delta"),
             ("v1.1 base\n(used throughout)", 3.92, "abs"), ("v1.2 Apr\nbacktested ramp", -0.96, "delta"),
             ("Sensitivity\ncase", 2.96, "abs")]
    fig, ax = frame("A model's history is part of its evidence",
                    "Middle-path NPV of full entry ($M) through the change log. Bars are levels; floating bars are changes.",
                    h=3.7, source="Lab 4 · change log, Section 3.5")
    level = 0
    for i, (nm, v, kind) in enumerate(steps):
        if kind == "abs":
            col = OPT["A"] if "used" in nm else tint(OPT["A"], 0.45)
            ax.bar(i, v, width=0.56, color=col, edgecolor="none"); level = v
            ax.text(i, v + 0.12, f"{v:.2f}", ha="center", fontsize=8.5, fontweight="semibold")
        else:
            ax.bar(i, v, bottom=level, width=0.56, color=tint(SCN["Squeeze"], 0.75), edgecolor="none")
            ax.text(i, level + 0.12, f"{v:+.2f}", ha="center", fontsize=8.5, fontweight="semibold", color=SCN["Squeeze"])
            level += v
    ax.set_xticks(range(len(steps)), [s[0] for s in steps], fontsize=7.6)
    ax.set_ylim(0, 5.8); ax.set_ylabel("NPV, $M"); ax.grid(axis="x", visible=False)
    return finish(fig, top=0.80, bottom=0.18)


def fig_breakeven_map():
    M = np.linspace(240, 520, 300); s = np.linspace(0.03, 0.15, 300)
    MM, SS = np.meshgrid(M, s)
    fig, (a1, a2) = frame("Squeeze is not a worse Middle — it is the other side of a cliff",
                          "Left: full-ramp annual contribution M·s·g − F at g = 0.32. Right: same parameters, two paths (Middle).",
                          ncols=2, h=4.0, source="Lab 5 · contribution at full ramp; NPV at 10%",
                          gridspec_kw=dict(width_ratios=[1.1, 1], wspace=0.3))
    C = MM * SS * 0.32 - core.FIXED
    levels = np.linspace(-6, 12, 10)
    cmap = ListedColormap([tint(SCN["Squeeze"], a) for a in (0.75, 0.55, 0.38, 0.22)] + [tint(OPT["A"], a) for a in (0.15, 0.28, 0.42, 0.56, 0.7)])
    a1.contourf(MM, SS * 100, C, levels=levels, cmap=cmap, extend="both")
    cs = a1.contour(MM, SS * 100, C, levels=[0], colors=INK, linewidths=1.4)
    a1.clabel(cs, fmt={0: "break-even"}, fontsize=7.6, inline_spacing=4)
    for nm in core.SCEN_NAMES:
        p = core.SCEN[nm]
        a1.plot(p["M"], p["s"] * 100, "o", color=SCN[nm], ms=9, mec=SURF, mew=2, zorder=5)
        a1.text(p["M"] + 8, p["s"] * 100 + 0.3, nm, fontsize=8, fontweight="semibold", color=INK)
    a1.set_xlabel("Addressable market M, $M per year"); a1.set_ylabel("Steady-state share s, %")
    a1.text(300, 3.3, "loses money\nevery year", fontsize=7.6, color=SCN["Squeeze"], fontweight="semibold")
    a1.text(430, 13.4, "earns its\nfixed cost", fontsize=7.6, color=OPT["A"], fontweight="semibold")
    a1.grid(False)
    gross = 400 * 0.09 * 0.34
    yrs = np.arange(1, 6)
    for ramp, col, nm, off in (([.3, .6, 1, 1, 1], OPT["A"], "Smooth 30/60/100", -0.18), ([.3, .2, 1, 1, 1], OPT["B"], "Relapse 30/20/100", 0.18)):
        cf = gross * np.array(ramp) - core.FIXED
        npv = -core.INVEST + (cf * core.DISC).sum()
        a2.bar(yrs + off, cf, width=0.34, color=col, edgecolor="none", label=f"{nm}: NPV {npv:+.2f}")
    a2.axhline(0, color=INK2, lw=0.8)
    a2.set_xlabel("Year"); a2.set_ylabel("Annual contribution, $M"); a2.legend(loc="upper left", fontsize=7.4); a2.set_ylim(-5, 9.5)
    a2.set_xticks(yrs); a2.grid(axis="x", visible=False)
    a2.set_title("Same endpoints, different order", loc="left", fontsize=9, pad=4)
    return finish(fig, top=0.78, left=0.08, bottom=0.16)


# ---------------------------------------------------------------------------
# Part IV
# ---------------------------------------------------------------------------
def fig_risk_profile():
    vi = core.mc_independent(); vc, _ = core.mc_correlated()
    si, sc = core.fan_stats(vi), core.fan_stats(vc)
    fig, ax = frame("Correlation does not add losses — it makes them deeper",
                    "Chance that full-entry NPV falls below each value. Same model; two claims about how the drivers move.",
                    h=4.0, source="Lab 6 (both runs) · seed 2026 · correlated run: scenario drawn first, drivers within ±10%")
    x = np.linspace(-30, 40, 500)
    ax.plot(x, np.searchsorted(np.sort(vi), x) / len(vi), color=OPT["A"], label="Drivers independent (Lab 6)")
    ax.plot(x, np.searchsorted(np.sort(vc), x) / len(vc), color=SCN["Squeeze"], label="Drivers move together (scenario-correlated)")
    for xx, txt, ha in ((0, " break-even", "left"), (-10, "a serious wound (−10) ", "right")):
        ax.axvline(xx, color=INK2, lw=0.8)
        ax.text(xx, 0.98, txt, transform=ax.get_xaxis_transform(), fontsize=7.4, color=INK2, va="top", ha=ha)
    for xx, a, b in ((0, si["p_loss"], sc["p_loss"]), (-10, si["p_cat"], sc["p_cat"])):
        ax.plot([xx], [a], "o", color=OPT["A"], ms=7, mec=SURF, mew=2, zorder=5)
        ax.plot([xx], [b], "o", color=SCN["Squeeze"], ms=7, mec=SURF, mew=2, zorder=5)
        ax.text(xx + 0.8, a, f"{a:.1%}", color=INK, fontsize=8, va="center" if xx else "bottom")
        ax.text(xx + 0.8, b, f"{b:.1%}", color=INK, fontsize=8, va="top" if xx else "center")
    ax.set_xlabel("Full-entry NPV, $M"); ax.set_ylabel("P(NPV below this value)")
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0))
    ax.legend(loc="lower right", fontsize=7.6); ax.set_xlim(-30, 40); ax.set_ylim(0, 1)
    return finish(fig, top=0.80)


def fig_tornado():
    base, sc, pct = core.tornado()
    fig, (a1, a2) = frame("A tornado is only as honest as its bounds",
                          "Full-entry NPV around the Middle case (3.92). Same model, two conventions for 'low' and 'high'.",
                          ncols=2, h=3.8, source="Lab 7 · F moved ±20% in both panels", sharey=True,
                          gridspec_kw=dict(wspace=0.12))
    order = ["s", "M", "F", "g"]
    names = {"s": "Share s", "M": "Market M", "F": "Fixed cost F", "g": "Margin g"}
    for ax, data, ttl in ((a1, sc, "Scenario bounds"), (a2, pct, "±20% bounds: M, s, g look identical")):
        for i, k in enumerate(order):
            lo, hi = data[k]
            ax.barh(i, lo - base, left=base, height=0.55, color=tint(SCN["Squeeze"], 0.7), edgecolor="none")
            ax.barh(i, hi - base, left=base, height=0.55, color=tint(OPT["A"], 0.7), edgecolor="none")
            ax.text(min(lo, hi) - 0.6, i, f"{min(lo, hi):.1f}", ha="right", va="center", fontsize=7.6, color=INK2)
            ax.text(max(lo, hi) + 0.6, i, f"{max(lo, hi):.1f}", ha="left", va="center", fontsize=7.6, color=INK2)
        ax.axvline(base, color=INK, lw=0.9)
        ax.set_title(ttl, loc="left", fontsize=9, pad=4); ax.set_xlim(-16, 21); ax.grid(axis="y", visible=False)
        ax.set_xlabel("NPV, $M")
    a1.set_yticks(range(4), [names[k] for k in order]); a1.invert_yaxis()

    return finish(fig, top=0.78, left=0.12, bottom=0.15)


def heat_table(ax, data, rows, cols, fmt="{:.2f}", cmap_hex=SCN["Squeeze"], highlight_min_col=None, vmax=None):
    data = np.asarray(data, float); vmax = vmax or data.max()
    for i in range(len(rows)):
        for j in range(len(cols)):
            v = data[i, j]
            ax.add_patch(plt.Rectangle((j + 0.04, i + 0.04), 0.92, 0.92, color=tint(cmap_hex, 0.08 + 0.75 * v / vmax), lw=0))
            ax.text(j + 0.5, i + 0.5, fmt.format(v), ha="center", va="center", fontsize=9, color=INK,
                    fontweight="semibold" if v == 0 else "normal")
    ax.set_xlim(0, len(cols)); ax.set_ylim(len(rows), 0)
    ax.set_xticks(np.arange(len(cols)) + 0.5, cols); ax.set_yticks(np.arange(len(rows)) + 0.5, rows)
    ax.grid(False); ax.tick_params(length=0)
    for s in ax.spines.values():
        s.set_visible(False)


def fig_regret():
    A, C = [26.29, 3.92, -18.78], [16.19, 0.33, -15.77]          # as printed in Tables 4.3 and 6.4
    naive = np.column_stack([A, [16.43, -0.15, -16.98], C])
    rev = np.column_stack([A, [16.40, -0.53, -3.61], C])
    rn, rr = core.regret(naive), core.regret(rev)
    fig, (a1, a2) = frame("Regret depends on how honestly the options are drawn",
                          "Regret = best available NPV in that scenario minus the option's NPV ($M). Bottom row: the worst regret.",
                          ncols=2, h=3.6, source="Labs 8 and 11", gridspec_kw=dict(wspace=0.35))
    rows = list(core.SCEN_NAMES) + ["Max regret"]
    cols = ["A Full", "B Staged", "C Defer"]
    for ax, rg, ttl in ((a1, rn, "Naive table: minimax → A"), (a2, rr, "B as a strategy: minimax → B")):
        d = np.vstack([rg, rg.max(axis=0)])
        heat_table(ax, d, rows, cols, vmax=16)
        j = int(np.argmin(rg.max(axis=0)))
        ax.add_patch(plt.Rectangle((j + 0.04, 3.04), 0.92, 0.92, fill=False, ec=INK, lw=1.6))
        ax.set_title(ttl, loc="left", fontsize=9, pad=6)
        ax.axhline(3, color=SURF, lw=3)
    return finish(fig, top=0.76, bottom=0.08, left=0.11)


def _ternary_xy(P):
    P = np.asarray(P, float)
    h = np.sqrt(3) / 2
    return P[:, 2] + 0.5 * P[:, 0], h * P[:, 0]       # Middle (0,0), Squeeze (1,0), Tailwind (0.5,h)


def _ternary_axes(ax):
    h = np.sqrt(3) / 2
    ax.add_patch(Polygon([[0, 0], [1, 0], [0.5, h]], closed=True, fill=False, ec=INK2, lw=1))
    ax.text(0.5, h + 0.03, "Tailwind certain", ha="center", fontsize=7.8, color=INK2)
    ax.text(-0.02, -0.045, "Middle\ncertain", ha="center", va="top", fontsize=7.8, color=INK2)
    ax.text(1.02, -0.045, "Squeeze\ncertain", ha="center", va="top", fontsize=7.8, color=INK2)
    for f in (0.2, 0.4, 0.6, 0.8):     # P(Squeeze) gridlines
        a = np.array([[1 - f, 0, f], [0, 1 - f, f]])
        x, y = _ternary_xy(a); ax.plot(x, y, color=SURF, lw=0.7, zorder=3)
        ax.text(x[1] + 0.012, y[1] - 0.012, f"{f:.0%}", fontsize=6.4, color=MUTED, ha="left", va="top", rotation=-60)
    ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-0.12, 1.12); ax.set_ylim(-0.14, h + 0.08)


def _simplex_values(kind, erosion):
    if kind == "naive":
        G = core.simplex_grid(0.01)
        return G, np.column_stack([G @ core.A_COL, G @ core.B_NAIVE, G @ core.C_COL])
    G = core.simplex_grid(0.02)
    return G, np.array([core.option_values_under(p, erosion=erosion)[[0, 1, 3]] for p in G])


def fig_simplex(kind="naive", erosion=0.10):
    G, V = _simplex_values(kind, erosion)
    keys = ["A", "B", "C"]
    if kind == "naive":
        title = "Before arguing about probabilities, map where they would matter"
        sub = "Which option has the highest expected NPV, for every possible probability over the three scenarios (naive option table)."
        src = "Lab 8A · naive columns of Table 4.3 · exact on a 0.01 grid"
        names = ["A  Full entry", "B  Staged (naive)", "C  Defer (static)"]
    else:
        title = "Priced as strategies, the map splits into three territories"
        sub = f"Highest expected NPV for every probability vector: A full, B staged (tree re-solved), C defer-and-learn ({erosion:.0%} erosion)."
        src = "Lab 10A · tis_core.option_values_under · 0.02 grid, linearly interpolated"
        names = ["A  Full entry", "B  Staged (strategy)", "C  Defer-and-learn"]
    fig, ax = frame(title, sub, h=5.0, source=src)
    # raster: interpolate each option's EV over the simplex, then colour by the winner
    x, y = _ternary_xy(G); tri = mtri.Triangulation(x, y)
    interp = [mtri.LinearTriInterpolator(tri, V[:, k]) for k in range(3)]
    gx, gy = np.meshgrid(np.linspace(0, 1, 700), np.linspace(0, np.sqrt(3) / 2, 606))
    Z = np.ma.stack([f(gx, gy) for f in interp])
    inside = ~np.ma.getmaskarray(Z[0])
    win = np.argmax(np.ma.filled(Z, -1e9), axis=0)
    rgb = np.ones(gx.shape + (3,))
    for k, key in enumerate(keys):
        rgb[(win == k) & inside] = tint(OPT[key], 0.38)
    ax.imshow(rgb, origin="lower", extent=(0, 1, 0, np.sqrt(3) / 2), interpolation="nearest", zorder=1)
    _ternary_axes(ax)
    ax.text(0.5, -0.12, "P(Squeeze) rises toward the right →", ha="center", fontsize=7.2, color=MUTED)
    px, py = _ternary_xy(core.PRIOR[None, :])
    gwin = np.argmax(V, axis=1)
    d = np.abs(G - core.PRIOR).sum(axis=1) / 2
    prior_win = gwin[np.argmin(d)]
    i = np.argmin(np.where(gwin != prior_win, d, 9))
    fx, fy = _ternary_xy(G[i][None, :])
    ax.annotate("", xy=(fx[0], fy[0]), xytext=(px[0], py[0]), arrowprops=dict(arrowstyle="-|>", color=INK, lw=1.2), zorder=6)
    ax.plot(px, py, "o", color=INK, ms=7, mec=SURF, mew=2, zorder=7)
    ax.annotate(f"Board's prior 25 / 50 / 25.\n{d[i] * 100:.0f} points of probability\nmoved toward Squeeze\nflip the winner",
                xy=(px[0], py[0]), xytext=(-0.1, 0.60), fontsize=7.6, color=INK, fontweight="semibold",
                arrowprops=dict(arrowstyle="-", color=INK2, lw=0.8), zorder=7)
    shares = np.bincount(win[inside], minlength=3) / inside.sum()
    for k, (key, nm) in enumerate(zip(keys, names)):
        ax.add_patch(plt.Rectangle((0.74, 0.80 - k * 0.075), 0.035, 0.045, color=tint(OPT[key], 0.38), transform=ax.transAxes, clip_on=False))
        txt = f"{nm}  ({shares[k]:.0%})" if shares[k] > 0.005 else f"{nm}  (never best)"
        ax.text(0.785, 0.822 - k * 0.075, txt, transform=ax.transAxes, fontsize=7.6, va="center", color=INK)
    if kind != "naive":
        corners = np.array([[.1, .8, .1], [.4, .5, .1], [.4, .2, .4], [.1, .5, .4]])
        cx, cy = _ternary_xy(corners)
        ax.add_patch(Polygon(np.column_stack([cx, cy]), closed=True, fill=False, ec=INK, lw=1.1, zorder=5))
        ax.annotate("credal set: P(Tailwind) and\nP(Squeeze) each between 10% and 40%", xy=(cx[2], cy[2]), xytext=(0.78, 0.36),
                    fontsize=7.2, color=INK2, arrowprops=dict(arrowstyle="-", color=INK2, lw=0.8), zorder=7)
    fig.subplots_adjust(top=1 - fig._head_in / fig.get_size_inches()[1], bottom=0.04, left=0.02, right=0.98)
    return fig


def fig_credal_intervals(erosion=0.10):
    G = core.simplex_grid(0.02)
    cs = (G[:, 0] >= 0.1 - 1e-9) & (G[:, 0] <= 0.4 + 1e-9) & (G[:, 2] >= 0.1 - 1e-9) & (G[:, 2] <= 0.4 + 1e-9)
    V = np.array([core.option_values_under(p, erosion=erosion) for p in G[cs]])
    at_prior = core.option_values_under(core.PRIOR, erosion=erosion)
    names = ["A  Full entry", "B  Staged (strategy)", "C  Defer (static)", "C  Defer-and-learn"]
    keys = ["A", "B", "C", "C"]; styles = ["-", "-", "--", "-"]
    fig, ax = frame("When the probabilities are contested, compare ranges, not points",
                    "Expected NPV over every probability vector in the credal set (Tailwind and Squeeze each 10–40%). Dot: the board's prior.",
                    h=3.6, source=f"Lab 10A · defer-and-learn at {erosion:.0%} erosion, σ_M = 40")
    for i in range(4):
        lo, hi = V[:, i].min(), V[:, i].max()
        ax.plot([lo, hi], [i, i], color=OPT[keys[i]], lw=7 if styles[i] == "-" else 2.2, ls=styles[i], solid_capstyle="round", alpha=0.9 if styles[i] == "-" else 1)
        ax.plot(at_prior[i], i, "o", color=INK, ms=6, mec=SURF, mew=1.5, zorder=5)
        ax.text(hi + 0.35, i, f"{lo:+.2f} to {hi:+.2f}", va="center", fontsize=7.8, color=INK)
    ax.axvline(0, color=INK2, lw=0.9)
    ax.set_yticks(range(4), names); ax.invert_yaxis(); ax.set_xlim(-6, 17); ax.set_xlabel("Expected NPV, $M")
    ax.grid(axis="y", visible=False)
    ax.text(16.6, 2.5, "Only defer-and-learn keeps a positive\nexpected value everywhere in the set", fontsize=7.4, color=INK2, ha="right", va="center")
    return finish(fig, top=0.80, left=0.22)


# ---------------------------------------------------------------------------
# Part V
# ---------------------------------------------------------------------------
def fig_overfit():
    rng = np.random.default_rng(5)
    x = np.linspace(0, 10, 60); y = 2 + 0.5 * x + rng.normal(0, 1.5, 60)
    tr, te, ytr, yte = x[:36], x[36:48], y[:36], y[36:48]
    degs = np.arange(1, 10); trn, tst = [], []
    for d in degs:
        c = np.polyfit(tr, ytr, d)
        trn.append(np.sqrt(np.mean((np.polyval(c, tr) - ytr) ** 2))); tst.append(np.sqrt(np.mean((np.polyval(c, te) - yte) ** 2)))
    leak = yte + rng.normal(0, 0.1, len(te)); leak_rmse = np.sqrt(np.mean((leak - yte) ** 2))
    fig, ax = frame("The fit that flatters the analyst is the fit that fails in the world",
                    "Polynomial models of a truly linear series: error on the data that built them vs on twelve unseen points (log scale).",
                    h=3.8, source="Lab 9 · seed 5")
    ax.plot(degs, trn, color=OPT["A"], marker="o", ms=6, mec=SURF, mew=1.5, label="Training error")
    ax.plot(degs, tst, color=OPT["B"], marker="o", ms=6, mec=SURF, mew=1.5, label="Test error (unseen data)")
    ax.axhline(1.5, color=INK2, lw=0.8); ax.text(9.1, 1.5, "true noise 1.5", fontsize=7.4, color=INK2, va="bottom", ha="right")
    ax.plot([9.6], [leak_rmse], "D", color=SCN["Squeeze"], ms=6)
    ax.text(9.45, leak_rmse, f"Leaked feature {leak_rmse:.2f}:\ntoo good to be true", fontsize=7.4, color=SCN["Squeeze"], ha="right", va="center")
    ax.set_yscale("log"); ax.set_xticks(degs); ax.set_xlabel("Model complexity (polynomial degree)"); ax.set_ylabel("RMSE (log scale)")
    ax.text(9.15, tst[-1] * 0.62, f"degree 9: {tst[-1]:.0f}", ha="center", va="top", fontsize=7.6, color=OPT["B"], fontweight="semibold")
    ax.legend(loc="upper left", fontsize=7.6); ax.set_xlim(0.6, 9.9)
    return finish(fig, top=0.80)


def fig_drift():
    d = core.drift_world()
    t = d["t"]
    fig = plt.figure(figsize=(7.2 * S, 6.0 * S))
    fig.text(0.012, 0.985, "A validated model can walk into a different world", fontsize=11.5, fontweight="semibold", va="top")
    fig.text(0.012, 0.95, "Pilot-city sales model, trained on months 1–36.\nFrom month 40 the incumbent starts matching promotions.",
             fontsize=8.8, color=INK2, va="top", linespacing=1.25)
    gs = fig.add_gridspec(3, 1, height_ratios=[1.25, 1, 0.8], hspace=0.55, top=0.84, bottom=0.09, left=0.12, right=0.97)
    a1, a2, a3 = (fig.add_subplot(gs[i]) for i in range(3))
    for ax in (a1, a2, a3):
        ax.axvspan(0.5, 36.5, color="#f6f5f2", lw=0, zorder=0)
        ax.axvline(d["shift_at"], color=INK2, lw=0.8)
        ax.set_xlim(0.5, t.max() + 0.5)
    a1.plot(t, d["sales"], color=INK, lw=1.6, label="Actual sales")
    a1.plot(t, d["pred"], color=OPT["A"], lw=2, label="Model forecast")
    a1.text(18, a1.get_ylim()[1], "training window", fontsize=7.4, color=INK2, ha="center", va="top")
    a1.text(d["shift_at"] + 0.4, a1.get_ylim()[1], "regime\nchange", fontsize=7.4, color=INK2, va="top")
    a1.set_ylabel("Units, thousands"); a1.legend(loc="lower left", fontsize=7.4, ncols=2)
    a2.plot(t[36:], d["cusum"][36:], color=SCN["Squeeze"], lw=2)
    a2.axhline(d["h"], color=INK, lw=0.9); a2.text(1.5, d["h"], "escalation threshold (CUSUM h = 4)", fontsize=7.4, va="bottom")
    if d["alarm"]:
        a2.plot(d["alarm"], d["cusum"][d["alarm"] - 1], "o", color=SCN["Squeeze"], ms=7, mec=SURF, mew=2)
        a2.text(d["alarm"] + 0.8, d["cusum"][d["alarm"] - 1] + 6, f"alarm: month {d['alarm']}", fontsize=7.8, color=INK, fontweight="semibold", va="bottom")
    a2.set_ylabel("Error monitor"); a2.set_ylim(0, 40); a2.set_title("Outcome monitor: cumulative under-forecast", loc="left", fontsize=8.6, pad=3)
    lo, hi = d["train_range"]
    a3.axhspan(lo, hi, color=tint(OPT["A"], 0.15), lw=0)
    a3.plot(t, d["gap"], color=INK2, lw=1.4)
    a3.plot(t[d["outside"]], d["gap"][d["outside"]], "o", color=OPT["B"], ms=5)
    a3.set_ylabel("Price gap"); a3.set_xlabel("Month")
    a3.set_title("Input monitor: price gap vs training range (shaded) — it barely notices", loc="left", fontsize=8.6, pad=3)
    fig.text(0.012, 0.012, "Lab 9A · tis_core.drift_world · seed 9", fontsize=7, color=MUTED)
    return fig


# ---------------------------------------------------------------------------
# Part VI
# ---------------------------------------------------------------------------
def fig_weight_stability():
    wn, tn = core.weight_perturbation(core.SCORE_NAIVE); wr, tr = core.weight_perturbation(core.SCORE_REVISED)
    rows = [("Weighted sum · naive table", wn), ("TOPSIS · naive table", tn), ("Weighted sum · B as strategy", wr), ("TOPSIS · B as strategy", tr)]
    fig, ax = frame("Which winners survive an honest argument about the weights?",
                    "Share of 4,000 perturbed weight sets (Dirichlet, centred on the board's weights) under which each option wins.",
                    h=3.4, source="Lab 11 (extended) · concentration 40 · seed 611")
    for i, (nm, w) in enumerate(rows):
        left = 0
        for k, key in enumerate("ABC"):
            if w[k] > 0:
                ax.barh(i, w[k], left=left, height=0.58, color=OPT[key], edgecolor=SURF, linewidth=2)
                if w[k] >= 0.07:
                    ax.text(left + w[k] / 2, i, f"{key} {w[k]:.0%}", ha="center", va="center", fontsize=7.8, color=SURF, fontweight="semibold")
            left += w[k]
    ax.set_yticks(range(4), [r[0] for r in rows]); ax.invert_yaxis(); ax.set_xlim(0, 1)
    ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0)); ax.grid(axis="y", visible=False)
    return finish(fig, top=0.76, left=0.27, bottom=0.14)


def _discrete_cdf(ax, vals, probs, color, ls="-", label=None, lw=2):
    o = np.argsort(vals); v = np.asarray(vals)[o]; p = np.cumsum(np.asarray(probs)[o])
    xs = np.concatenate([[-30], np.repeat(v, 2), [32]]); ys = np.concatenate([[0, 0], np.repeat(p, 2)[:-1], [p[-1]]])
    ax.plot(xs, ys, color=color, ls=ls, lw=lw, label=label, drawstyle="default")


def fig_option_profiles():
    sol = core.staged_policy(); dl = core.defer_and_learn(erosion=0.10)
    fig, ax = frame("The staged option's real product is a lighter left tail",
                    "Chance of ending below each NPV, by option. Dashed = priced as a straitjacket; solid = priced as a strategy.",
                    h=4.0, source="Labs 10 and 10A · exact tree solution · defer-and-learn at 10% erosion")
    P = core.PRIOR
    _discrete_cdf(ax, core.A_COL, P, OPT["A"], label="A  Full entry")
    _discrete_cdf(ax, core.B_NAIVE, P, OPT["B"], ls="--", lw=1.6, label="B  Staged, always proceed")
    bv = np.concatenate([core.PILOT, core.PILOT + core.PROCEED]); bp = np.concatenate([P * (1 - sol["p_go"]), P * sol["p_go"]])
    _discrete_cdf(ax, bv, bp, OPT["B"], label="B  Staged with exit rule")
    _discrete_cdf(ax, core.C_COL, P, OPT["C"], ls="--", lw=1.6, label="C  Defer, enter regardless")
    cv = np.concatenate([np.full(3, -0.3), dl["static"] - 0.3]); cp = np.concatenate([P * (1 - dl["p_go"]), P * dl["p_go"]])
    _discrete_cdf(ax, cv, cp, OPT["C"], label="C  Defer-and-learn")
    ax.axvline(-10, color=INK2, lw=0.8); ax.text(-10, 0.97, " NPV −10", transform=ax.get_xaxis_transform(), fontsize=7.4, color=INK2, va="top")
    ax.axvline(0, color=INK2, lw=0.8)
    ax.set_xlim(-22, 30); ax.set_ylim(0, 1.02)
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0))
    ax.set_xlabel("Five-year NPV, $M"); ax.set_ylabel("P(NPV ≤ x)")
    ax.legend(loc="lower right", fontsize=7.4)
    ax.text(-21.5, 0.29, "A: one future in four\nends at −18.8", fontsize=7.4, color=OPT["A"], fontweight="semibold")
    ax.text(-9.4, 0.10, f"B with exit:\n{sol['p_cat']:.1%} below −10", fontsize=7.4, color=OPT["B"], fontweight="semibold", va="center")
    return finish(fig, top=0.80)


def fig_signal_quality():
    sig = np.linspace(0.003, 0.05, 48)
    ev = np.array([core.staged_policy(sigma=s, grid=3001)["ev"] for s in sig])
    evsi = np.array([core.evsi_evpi(sigma=s)[0] for s in sig])
    bias = np.linspace(0, 0.03, 31)
    ev_unc = np.array([core.staged_policy(true_bias=b, grid=3001)["ev"] for b in bias])
    ev_cor = np.array([core.staged_policy(true_bias=b, assumed_bias=b, grid=3001)["ev"] for b in bias])
    fig, (a1, a2) = frame("An exit rule is worth exactly as much as the signal it reads",
                          "Left: staged entry's value as pilot noise grows — even a perfect pilot leaves it below A. Right: the pilot city flatters the signal by δ points.",
                          ncols=2, h=4.0, source="Lab 10A · exact tree solution · A = 3.84 reference",
                          gridspec_kw=dict(wspace=0.28), sharey=True)
    a1.plot(sig * 100, ev, color=OPT["B"], label="B staged with exit rule")
    a1.plot(sig * 100, evsi, color=OPT["B"], lw=1.2, alpha=0.55, label="EVSI of the signal")
    a1.axhline(3.84, color=OPT["A"], lw=1.2); a1.text(4.9, 3.84, "A full entry 3.84", color=OPT["A"], fontsize=7.6, ha="right", va="bottom")
    a1.axhline(-0.21, color=OPT["B"], lw=1.2, ls="--"); a1.text(4.9, -0.21, "B, always proceed −0.21", color=OPT["B"], fontsize=7.6, ha="right", va="bottom")
    a1.axvline(1.5, color=INK2, lw=0.8); a1.text(1.55, 0.60, " assumed\n 1.5 pp", transform=a1.get_xaxis_transform(), fontsize=7.4, va="top", color=INK2)
    a1.set_xlabel("Pilot observation noise σ, percentage points"); a1.set_ylabel("Expected NPV, $M")
    a1.legend(loc="lower left", bbox_to_anchor=(0, 0.1), fontsize=7.3)
    a2.plot(bias * 100, ev_unc, color=OPT["B"], label="Team reads signal at face value")
    a2.plot(bias * 100, ev_cor, color=OPT["B"], lw=1.2, alpha=0.55, label="Team corrects for the flattery")
    a2.axhline(3.84, color=OPT["A"], lw=1.2)
    a2.set_xlabel("Pilot-city flattery δ, percentage points"); a2.legend(loc="lower left", fontsize=7.3)
    i = np.argmin(np.abs(bias - 0.01))
    a2.plot(bias[i] * 100, ev_unc[i], "o", color=OPT["B"], ms=6, mec=SURF, mew=1.5)
    a2.text(bias[i] * 100 + 0.1, ev_unc[i] + 0.2, f"δ = 1 pt: {ev_unc[i]:.2f}", fontsize=7.6, color=INK)
    return finish(fig, top=0.78, left=0.08, bottom=0.16)


def fig_waiting_frontier():
    e = np.linspace(0, 0.20, 41)
    cl40 = np.array([core.defer_and_learn(sigma_M=40, erosion=x)["ev"] for x in e])
    cl80 = np.array([core.defer_and_learn(sigma_M=80, erosion=x)["ev"] for x in e])
    cst = np.array([float(core.PRIOR @ np.array([core.defer_entry(**core.SCEN[n], share_kept=1 - x) for n in core.SCEN_NAMES])) for x in e])
    b = core.staged_policy()["ev"]
    fig, ax = frame("Waiting is an option too — and its price is written in lost share",
                    "Expected NPV against the share a year's delay gives away. Defer-and-learn buys a 0.3 market study, then decides.",
                    h=4.1, source="Lab 10A · tis_core.defer_and_learn · study reads market size M with noise σ_M")
    ax.axhline(3.84, color=OPT["A"], lw=1.6); ax.text(0.199, 3.84, "A  Full entry 3.84", color=OPT["A"], fontsize=7.8, ha="right", va="bottom", fontweight="semibold")
    ax.axhline(b, color=OPT["B"], lw=1.6); ax.text(0.199, b, f"B  Staged with exit {b:.2f}", color=OPT["B"], fontsize=7.8, ha="right", va="bottom", fontweight="semibold")
    ax.plot(e, cl40, color=OPT["C"], label="C  Defer-and-learn, good study (σ_M = 40)")
    ax.plot(e, cl80, color=OPT["C"], lw=1.2, alpha=0.6, label="C  Defer-and-learn, weak study (σ_M = 80)")
    ax.plot(e, cst, color=OPT["C"], ls="--", lw=1.6, label="C  Defer, enter regardless (as first priced)")
    k = np.argmin(np.abs(cl40 - b))
    ax.plot(e[k], cl40[k], "o", color=OPT["C"], ms=7, mec=SURF, mew=2, zorder=5)
    ax.text(e[k] + 0.004, cl40[k] + 0.25, f"ties staged at ≈{e[k]:.0%} erosion", fontsize=7.8, color=INK)
    ax.axvspan(0.05, 0.15, color="#f6f5f2", lw=0, zorder=0)
    ax.text(0.10, -0.75, "board's belief: 5–15%", ha="center", fontsize=7.4, color=INK2)
    ax.set_xticks([0, .05, .10, .15, .20]); ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0))
    ax.set_xlabel("Share eroded while Meridian waits a year"); ax.set_ylabel("Expected NPV, $M"); ax.set_xlim(0, 0.2); ax.set_ylim(-7.4, 4.5)
    ax.legend(loc="lower left", fontsize=7.2)
    return finish(fig, top=0.80)


def fig_game_threshold():
    p = np.linspace(0, 1, 201)
    full = -25 * p + 26 * (1 - p); stg = -6 * p + 18 * (1 - p); ps = core.fight_threshold()
    fig, ax = frame("Strategy turns 'will they fight?' into one number you can argue about",
                    "Meridian's expected payoff from the entry game as a function of the probability that the incumbent fights.",
                    h=3.7, source="Lab 12 · payoffs of Table 6.7")
    ax.plot(p, full, color=OPT["A"], label="Full entry"); ax.plot(p, stg, color=OPT["B"], label="Staged entry")
    ax.axvline(ps, color=INK, lw=0.9)
    ax.text(ps + 0.01, 22, f"Stage if P(fight) > {ps:.0%}", fontsize=8.2, color=INK, fontweight="semibold")
    ax.text(ps - 0.01, -6, "← full entry\n    pays more", color=OPT["A"], fontsize=7.8, ha="right", fontweight="semibold")
    ax.text(ps + 0.01, -6, "staged entry →\npays more", color=OPT["B"], fontsize=7.8, ha="left", fontweight="semibold")
    ax.text(0.01, -15, "Equilibrium analysis\nputs P(fight) near 0 for\na profit-driven incumbent.\nThe board prices the\nchance it is not one.", fontsize=7.2, color=INK2, va="center")
    ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0))
    ax.set_xlabel("Probability the incumbent fights"); ax.set_ylabel("Meridian's expected payoff"); ax.legend(loc="upper right", fontsize=7.6)
    return finish(fig, top=0.80)


def fig_hurwicz():
    a = np.linspace(0, 1, 201)
    rows = {"A": (26.29, -18.78), "B": (16.40, -16.98), "C": (16.19, -15.77)}
    fig, ax = frame("Under ignorance, your optimism is the decision",
                    "Hurwicz score α·best + (1 − α)·worst on the corrected table. B's worst is its worst reachable path (−16.98).",
                    h=3.6, source="Section 6.5 · corrected outcome table")
    for k, (b, w) in rows.items():
        ax.plot(a, core.hurwicz(b, w, a), color=OPT[k], label=OPT_NAME[k])
    cross = 3.01 / 13.11
    ax.axvline(cross, color=INK, lw=0.9); ax.text(cross + 0.01, 8, f"α = {cross:.2f}:\nbelow, defer;\nabove, full entry", fontsize=7.6)
    ax.axvline(0.35, color=GRID, lw=0.9); ax.text(0.36, -14, "the book's α = 0.35", fontsize=7.2, color=INK2)
    ax.set_xlabel("Optimism α"); ax.set_ylabel("Hurwicz score, $M"); ax.legend(loc="upper left", fontsize=7.6)
    return finish(fig, top=0.80)


def fig_dashboard():
    lenses = ["Expected value", "Weighted scorecard", "TOPSIS", "Minimax regret", "Maximin", "Hurwicz α=0.35",
              "Threat insurance (if Fight)", "Contested probabilities\n(worst-case EV, credal set)"]
    win = ["A", "C", "B", "B", "C", "A", "B", "C*"]
    basis = ["3.84 · 2.91 · 0.27", "C 0.650 · B 0.523 · A 0.500", "B 0.581 · A 0.553 · C 0.495", "B 9.89 · C 12.16 · A 15.17",
             "C −15.77 · B −16.98 · A −18.78", "A −3.01 · C −4.59 · B −5.30", "staged −6 vs full −25", "C* +0.46 · B −0.05 · A −2.92"]
    fig = plt.figure(figsize=(7.2, 4.6))
    ax = fig.add_axes([0.02, 0.05, 0.96, 0.78]); ax.axis("off"); ax.set_xlim(0, 100); ax.set_ylim(len(lenses) + 0.6, -0.8)
    fig.text(0.012, 0.975, "Every lens on one page: no method sweeps the table", fontsize=13, fontweight="semibold", va="top")
    fig.text(0.012, 0.925, "Winner by lens. C* = defer priced as a strategy (defer-and-learn, 10% erosion, Section 6.2.4).", fontsize=9.6, color=INK2, va="top")
    cols = {"A": 40, "B": 49, "C": 58, "C*": 67}
    for k, x in cols.items():
        ax.text(x, -0.4, {"A": "A Full", "B": "B Staged", "C": "C Defer", "C*": "C* Defer\n+learn"}[k], ha="center", va="bottom", fontsize=8.6, color=INK2, fontweight="semibold")
    for i, (l, w, b) in enumerate(zip(lenses, win, basis)):
        y = i + 0.5
        ax.add_patch(plt.Rectangle((0, i + 0.08), 100, 0.84, color="#f6f5f2" if i % 2 == 0 else SURF, lw=0))
        ax.text(1, y, l, va="center", fontsize=9.2, color=INK)
        for k, x in cols.items():
            col = OPT[k[0]]
            if k == w:
                ax.plot([x], [y], marker="o", ms=11, color=col, ls="none")
            else:
                ax.plot([x], [y], marker="o", ms=4, color=GRID, ls="none")
        ax.text(73, y, b, va="center", fontsize=8.0, color=INK2)
    fig.text(0.012, 0.012, "Sections 4.6, 4.7, 6.1–6.6 · Labs 8, 10A, 11, 12", fontsize=7, color=MUTED)
    return fig


# ---------------------------------------------------------------------------
# Part VII
# ---------------------------------------------------------------------------
def fig_tripwire():
    xs = np.linspace(0.0, 0.17, 600)
    fig, (a1, a2) = frame("A tripwire is a trade between false alarms and missed catastrophes",
                          "Left: where the pilot signal lands in each world. Right: every possible threshold, scored on both errors.",
                          ncols=2, h=4.0, source="Lab 13 · σ = 1.5 pp · exact normal probabilities",
                          gridspec_kw=dict(width_ratios=[1.15, 1], wspace=0.3))
    for i, nm in enumerate(core.SCEN_NAMES):
        y = np.exp(-0.5 * ((xs - core.PILOT_MUS[i]) / core.SIGMA) ** 2)
        a1.plot(xs * 100, y, color=SCN[nm]); a1.text(core.PILOT_MUS[i] * 100, 1.03, nm, ha="center", fontsize=8)
    cross = core.proceed_crossing()
    for x, txt in ((0.065, "tripwire 6.5%"), (cross, f"break-even {cross * 100:.1f}%")):
        a1.axvline(x * 100, color=INK, lw=0.9)
    a1.text(6.35, 1.24, "tripwire 6.5%", ha="right", va="center", fontsize=7.4); a1.text(cross * 100 + 0.15, 1.24, f"crossing {cross * 100:.1f}%", ha="left", va="center", fontsize=7.4)
    a1.set_ylim(0, 1.34); a1.set_xlim(1, 16); a1.set_xlabel("Pilot-city share at month 12, %"); a1.set_yticks([])
    a1.set_title("Signal by true world", loc="left", fontsize=9, pad=4)
    th = np.linspace(0.04, 0.10, 300); r = np.array([core.tripwire_rates(t) for t in th])
    a2.plot(r[:, 1], 1 - r[:, 2], color=INK, lw=1.8)
    for t, nm in ((0.065, "6.5% (chosen)"), (cross, f"{cross * 100:.1f}% (crossing)"), (0.055, "5.5%")):
        rr = core.tripwire_rates(t)
        a2.plot(rr[1], 1 - rr[2], "o", color=OPT["B"] if t == 0.065 else INK2, ms=7, mec=SURF, mew=2, zorder=5)
        a2.text(rr[1] + 0.012, 1 - rr[2] + 0.012, f"{nm}\n{rr[1]:.0%} false alarms · {1 - rr[2]:.0%} missed", fontsize=7.2)
    a2.set_xlim(0, 0.6); a2.set_ylim(0, 0.6)
    for f in (a2.xaxis, a2.yaxis):
        f.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0))
    a2.set_xlabel("False alarm: fires in a Middle world"); a2.set_ylabel("Missed: silent in a Squeeze world")
    a2.set_title("The threshold menu", loc="left", fontsize=9, pad=4)
    return finish(fig, top=0.78, left=0.05, bottom=0.16)


def fig_calibration():
    rng = np.random.default_rng(88); n = 200
    p_true = rng.uniform(0.1, 0.9, n); out = rng.random(n) < p_true
    p_cal = np.clip(p_true + rng.normal(0, 0.05, n), 0.02, 0.98)
    p_over = np.clip(0.5 + (p_true - 0.5) * 1.8 + rng.normal(0, 0.05, n), 0.02, 0.98)
    fig, ax = frame("Confidence is a claim; calibration is the audit of the claim",
                    "Stated probability vs how often it happened, 200 events. Dot size = number of forecasts in the bucket.",
                    h=4.2, w=6.0, source="Lab 14 · seed 88")
    ax.plot([0, 1], [0, 1], color=INK2, lw=0.9); ax.text(0.98, 0.03, "diagonal = perfect calibration", fontsize=7.2, color=INK2, ha="right")
    for p, col, nm in ((p_cal, OPT["A"], "Calibrated"), (p_over, OPT["B"], "Overconfident")):
        st, ob, nn = [], [], []
        for lo in np.arange(0, 1, 0.2):
            m = (p >= lo) & (p < lo + 0.2)
            if m.sum():
                st.append(lo + 0.1); ob.append(out[m].mean()); nn.append(m.sum())
        brier = np.mean((p - out) ** 2)
        ax.plot(st, ob, color=col, lw=1.6, zorder=3)
        ax.scatter(st, ob, s=np.array(nn) * 2.2, color=col, edgecolor=SURF, linewidth=1.5, zorder=4, label=f"{nm} (Brier {brier:.3f})")
    ax.annotate("said 90%,\nhappened 76%", xy=(0.9, 0.76), xytext=(0.66, 0.46), fontsize=7.4, color=INK,
                arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.8))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.set_aspect("equal")
    for f in (ax.xaxis, ax.yaxis):
        f.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0))
    ax.set_xlabel("Stated probability"); ax.set_ylabel("Observed frequency"); ax.legend(loc="upper left", fontsize=7.6)
    return finish(fig, top=0.83, left=0.1)


def fig_rooms():
    ns, r = core.estimate_rooms()
    fig, ax = frame("Twelve anchored opinions are worth fewer than two independent ones",
                    "Error of the group's average estimate of Meridian's share, by number of estimators (truth 9%, individual error ±2.5 pts).",
                    h=3.9, source="Lab 15A · tis_core.estimate_rooms · seed 15")
    styles = {"independent": (OPT["A"], "Independent, written before the meeting"),
              "shared": (OPT["C"], "Same data and consultant (ρ = 0.3)"),
              "anchored": (OPT["B"], "Open meeting, anchored on the first speaker")}
    for k, (col, nm) in styles.items():
        ax.plot(ns, r[k] * 100, color=col, marker="o", ms=4.5, mec=SURF, mew=1, label=nm)
        ax.text(12.25, r[k][-1] * 100, f"{r[k][-1] * 100:.2f}", va="center", fontsize=7.8, color=INK)
    ax.set_xlabel("Number of estimators"); ax.set_ylabel("RMSE of group estimate, share points")
    ax.set_xticks(ns); ax.set_xlim(0.5, 13); ax.set_ylim(0, 2.7); ax.legend(loc="lower left", fontsize=7.4)
    neff = r["independent"][0] ** 2 / r["anchored"][-1] ** 2
    ax.text(12.0, 2.42, f"Anchored room of 12 ≈ {neff:.1f} independent estimators", fontsize=7.8, color=OPT["B"], fontweight="semibold", ha="right")
    return finish(fig, top=0.80)


def fig_power():
    rng = np.random.default_rng(160)
    def world(n):
        q = np.clip(rng.normal(2.2, .7, n), 0, 4); link = q[:, None] + rng.normal(0, .6, (n, 7))
        a = np.clip(link + rng.normal(0, .45, link.shape), 0, 4).round().mean(1)
        b = np.clip(link + rng.normal(0, .45, link.shape), 0, 4).round().mean(1)
        return (a + b) / 2, .35 * (q - 2.2) + rng.normal(0, 1, n)
    ns = np.array([8, 12, 25, 50, 75, 100, 150, 200, 300, 400]); pw = []
    for n in ns:
        h = 0
        for _ in range(1500):
            dq, o = world(n); rr = np.corrcoef(dq, o)[0, 1]; h += rr * np.sqrt((n - 2) / (1 - rr * rr)) > 1.645
        pw.append(h / 1500)
    lab = {12: .18, 25: .27, 50: .40, 100: .67, 200: .96}
    fig, ax = frame("Process is real but quiet: how many decisions before the audit can speak",
                    "Chance a portfolio of n audited decisions shows the process edge (one-sided 5% test). Fresh simulated worlds.",
                    h=3.8, source="Lab 16 · fresh-world simulation, 1,500 portfolios per point · open circles: Lab 16's printed resampling estimates")
    ax.plot(ns, pw, color=OPT["A"], marker="o", ms=5, mec=SURF, mew=1)
    ax.plot(list(lab), list(lab.values()), "o", mfc="none", mec=INK2, ms=6)
    ax.axhline(0.8, color=INK2, lw=0.8); ax.text(395, 0.8, "80% power", fontsize=7.4, ha="right", va="bottom", color=INK2)
    i12 = list(ns).index(12)
    ax.text(13.5, pw[i12] - 0.1, f"Lab 15's twelve decisions: {pw[i12]:.0%}", fontsize=7.8, color=INK, va="bottom")
    ax.set_xscale("log"); ax.set_xticks([10, 25, 50, 100, 200, 400], ["10", "25", "50", "100", "200", "400"])
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0)); ax.set_ylim(0, 1.02)
    ax.set_xlabel("Audited decisions in the portfolio (log scale)"); ax.set_ylabel("Detection probability")
    return finish(fig, top=0.80)


def fig_audit_vector():
    links = ["Frame", "Evidence", "Model", "Futures", "Options", "Judgment", "Learning"]
    v12 = [3, 3, 3, 3, 3, 3, 2]; v2 = [3, 3, 3, 3, 2, 3, 2]
    fig, ax = frame("Report the chain, not the average: the weakest link is the headline",
                    "Meridian's Decision Quality Audit at commitment (record v1.2) and on independent re-audit (record v1.4), 0–4 scale.",
                    h=3.7, source="Section 7.5 · illustrative ratings of a fictional case")
    x = np.arange(7)
    ax.bar(x - 0.18, v12, width=0.34, color=tint(OPT["A"], 0.45), edgecolor="none", label="Audit at commitment (v1.2)")
    ax.bar(x + 0.18, v2, width=0.34, color=[SCN["Squeeze"] if v == 2 else OPT["A"] for v in v2], edgecolor="none", label="Re-audit (record v1.4)")
    ax.text(4.18, 2.08, "defer was a\nstraitjacket", ha="center", fontsize=7.2, color=INK, va="bottom")
    ax.text(6.18, 2.08, "nothing\nscored yet", ha="center", fontsize=7.2, color=INK, va="bottom")
    ax.set_xticks(x, [f"{i + 1} {l}" for i, l in enumerate(links)]); ax.set_ylim(0, 4.6); ax.set_yticks(range(5))
    ax.set_ylabel("Score, 0–4"); ax.legend(loc="upper right", fontsize=7.6, ncols=2)
    ax.grid(axis="x", visible=False)
    return finish(fig, top=0.80)


FIGURES = {
    "method_map": fig_method_map,
    "native_simulator": fig_native_simulator, "plan_vs_world": fig_plan_vs_world,
    "process_luck": fig_process_luck, "fan": fig_fan, "simpson": fig_simpson, "bayes": fig_bayes,
    "uplift": fig_uplift, "model_changelog": fig_model_changelog, "breakeven_map": fig_breakeven_map,
    "risk_profile": fig_risk_profile, "tornado": fig_tornado, "regret": fig_regret,
    "simplex_naive": lambda: fig_simplex("naive"), "overfit": fig_overfit, "drift": fig_drift,
    "weight_stability": fig_weight_stability, "option_profiles": fig_option_profiles,
    "signal_quality": fig_signal_quality, "waiting_frontier": fig_waiting_frontier,
    "game_threshold": fig_game_threshold, "hurwicz": fig_hurwicz,
    "simplex_strategy": lambda: fig_simplex("strategy"), "credal": fig_credal_intervals,
    "dashboard": fig_dashboard, "tripwire": fig_tripwire, "calibration": fig_calibration,
    "rooms": fig_rooms, "power": fig_power, "audit_vector": fig_audit_vector,
}

if __name__ == "__main__":
    import sys
    plt.switch_backend("Agg")          # script mode: write files, no window
    os.makedirs("figs", exist_ok=True)
    names = sys.argv[1:] or list(FIGURES)
    for nm in names:
        f = FIGURES[nm]()
        f.savefig(f"figs/{nm}.png", dpi=300 / S)
        plt.close(f)
        print("wrote", nm)
