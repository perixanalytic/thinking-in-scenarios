"""Thinking in Scenarios — Lab 0. Run: python lab00_single_story_plan.py"""
import numpy as np

# The pilot-city launch plan: each task's duration as the team imagines it going (median, weeks)
tasks = {"Distributor contract": 4, "Label approval": 3, "Packaging localisation": 3,
         "Warehouse set-up": 2, "Hiring city team": 4, "Retail listings": 4,
         "Launch marketing": 3, "First shipment": 3}
median = np.array(list(tasks.values()), dtype=float)
plan = median.sum()                       # the native simulator's answer: add up the typical cases

# The world: each task is right-skewed around its median (lognormal, sigma 0.5), and a shared
# shock (one regulator, one distributor, one busy team) moves every task together (sigma 0.25).
rng = np.random.default_rng(7)
n = 100_000
shared = rng.normal(0, 0.25, (n, 1))
own = rng.normal(0, 0.50, (n, len(median)))
total = (median * np.exp(own + shared)).sum(axis=1)

print(f"The plan (sum of typical durations): {plan:.0f} weeks")
print(f"Mean outcome:                        {total.mean():.1f} weeks")
print(f"Median outcome:                      {np.median(total):.1f} weeks")
print(f"P(finished within the plan):         {(total <= plan).mean():.0%}")
print(f"80% confidence date:                 {np.percentile(total, 80):.1f} weeks")
print(f"90% confidence date:                 {np.percentile(total, 90):.1f} weeks")

# Same tasks, no shared shock: dependence is what makes 'late' turn into 'very late'
total_ind = (median * np.exp(rng.normal(0, 0.50, (n, len(median))))).sum(axis=1)
print(f"\nWithout the shared shock, the 90% date would be {np.percentile(total_ind, 90):.1f} weeks:")
print("shared causes are what fatten the late tail.")
