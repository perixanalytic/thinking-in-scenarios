"""Thinking in Scenarios — Lab 16. Run: python lab16_audit_reliability_power.py"""
import numpy as np

rng = np.random.default_rng(16)
N, LINKS = 400, 7          # 400 decisions, seven links in the quality chain

# Latent process quality of each decision (0-4 scale), and a blind two-rater audit.
q = np.clip(rng.normal(2.2, 0.7, N), 0, 4)
def audit(q, noise=0.45):
    link = q[:, None] + rng.normal(0, 0.6, (len(q), LINKS))     # links vary around q
    return np.clip(link + rng.normal(0, noise, link.shape), 0, 4).round()

rater_a, rater_b = audit(q), audit(q)
dq_a, dq_b = rater_a.mean(axis=1), rater_b.mean(axis=1)
dq = (dq_a + dq_b) / 2

# Outcomes: a modest process edge buried in large luck (Lab 1's lesson, at portfolio scale).
outcome = 0.35 * (q - 2.2) + rng.normal(0, 1.0, N)

r = lambda a, b: np.corrcoef(a, b)[0, 1]
print("=== Reliability: do two blind raters agree? ===")
print(f"Rater A vs rater B (mean DQ):        r = {r(dq_a, dq_b):.2f}")
print(f"Audit DQ vs latent quality:           r = {r(dq, q):.2f}")

print("\n=== Validity: what predicts the outcome? ===")
print(f"Audit DQ vs outcome (n={N}):          r = {r(dq, outcome):+.2f}")
print(f"Latent quality vs outcome (ceiling):  r = {r(q, outcome):+.2f}")

order = np.argsort(dq)
bot, top = outcome[order[:N // 4]], outcome[order[-N // 4:]]
diff = top.mean() - bot.mean()
se = np.sqrt(top.var(ddof=1) / len(top) + bot.var(ddof=1) / len(bot))
print(f"Top-quartile minus bottom-quartile mean outcome: {diff:+.2f}  (95% CI {diff-1.96*se:+.2f} to {diff+1.96*se:+.2f})")

print("\n=== Power: how many decisions before the audit can speak? ===")
def detect(n, reps=2000):
    hits = 0
    for _ in range(reps):
        idx = rng.choice(N, n, replace=False)
        rr = r(dq[idx], outcome[idx])
        t = rr * np.sqrt((n - 2) / (1 - rr ** 2))
        hits += t > 1.645                      # one-sided, 5%
    return hits / reps
for n in (12, 25, 50, 100, 200):
    print(f"  portfolio of {n:3d} decisions: audit detects the process edge in {detect(n):4.0%} of samples")
