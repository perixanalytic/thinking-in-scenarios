"""Thinking in Scenarios — Lab 8A. Run: python lab08a_probability_map.py"""
import numpy as np

# Naive outcome table (Table 4.3): rows Tailwind, Middle, Squeeze
A = np.array([26.29, 3.92, -18.78])      # full entry
B = np.array([16.43, -0.15, -16.98])     # staged, always proceed
C = np.array([16.19, 0.33, -15.77])      # defer, enter regardless
prior = np.array([0.25, 0.50, 0.25])

# Every probability vector on a 1-point grid of the simplex
step = 0.01
P = np.array([(i * step, j * step, 1 - (i + j) * step)
              for i in range(101) for j in range(101 - i)])
P = np.clip(P, 0, 1)
ev = np.column_stack([P @ A, P @ B, P @ C])
winner = ev.argmax(axis=1)
print("Share of the probability simplex where each option has the highest E[NPV]:")
for name, share in zip(["A full", "B staged (naive)", "C defer"], np.bincount(winner, minlength=3) / len(P)):
    print(f"  {name:18s} {share:5.1%}")

# How far must belief move before the expected-value winner changes?
dist = np.abs(P - prior).sum(axis=1) / 2                 # total-variation distance
flip = np.where(winner != 0, dist, np.inf).argmin()
print(f"\nClosest probability vector where A stops winning: {np.round(P[flip], 2)}")
print(f"Distance from the board's prior: {dist[flip]:.2f} (i.e. {dist[flip] * 100:.0f} points of probability)")

# The indifference line between A and C
print("A beats C whenever 10.10*pT + 3.59*pM - 3.01*pS > 0")
print(f"With pT = 0.25 fixed, C wins only if P(Squeeze) > {(10.10*0.25 + 3.59*0.75) / (3.59 + 3.01):.2f}")
