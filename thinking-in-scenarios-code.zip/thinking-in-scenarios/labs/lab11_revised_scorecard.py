"""Thinking in Scenarios — Lab 11. Run: python lab11_revised_scorecard.py"""
import numpy as np
import pandas as pd

# Revised scenario table (B as adaptive strategy)
df_rev = pd.DataFrame({
    "A full entry": [26.29, 3.92, -18.78],
    "B staged":     [16.40, -0.53, -3.61],   # expected under adaptive policy
    "C defer":      [16.19, 0.33, -15.77],
}, index=["Tailwind", "Middle", "Squeeze"])
print("Revised scenario table:")
print(df_rev.round(2).to_string())

# Criteria matrix (with B's worst case = worst reachable path, not intended)
worst_reachable_B = -16.98
crit = ["ENPV", "Worst-case NPV", "P(loss)", "Attention", "Brand risk"]
benefit = dict(zip(crit, [True, True, False, False, False]))
w = np.array([0.35, 0.25, 0.15, 0.15, 0.10])

raw = pd.DataFrame(index=crit)
raw["A full entry"] = [3.84, -18.78, 0.25, 30.0, 4.0]
raw["B staged"]     = [2.91, worst_reachable_B, 0.75, 18.0, 3.0]
raw["C defer"]      = [0.27, -15.77, 0.25, 6.0, 1.5]
print("\nRaw scorecard (B as strategy):")
print(raw.round(2).to_string())

# Normalise and score
mat = raw.values.astype(float).T   # rows = options, cols = criteria
norm = np.zeros_like(mat)
for j in range(len(crit)):
    col = mat[:, j]; rng_ = col.max() - col.min()
    norm[:, j] = ((col - col.min()) if benefit[crit[j]] else (col.max() - col)) / rng_

print("\nWeighted-sum:", {c: float(v) for c, v in zip(raw.columns, np.round(norm @ w, 3))})

# TOPSIS
v = norm * w
d_b = np.linalg.norm(v - v.max(axis=0), axis=1)
d_w = np.linalg.norm(v - v.min(axis=0), axis=1)
print("TOPSIS:      ", {c: float(v) for c, v in zip(raw.columns, np.round(d_w / (d_b + d_w), 3))})

# Minimax regret
regret = df_rev.apply(lambda col: df_rev.max(axis=1) - col)
print("\nRegret table:")
print(regret.round(2).to_string())
print("\nMax regret:", regret.max().round(2).to_dict())
print("Minimax regret option:", regret.max().idxmin())
