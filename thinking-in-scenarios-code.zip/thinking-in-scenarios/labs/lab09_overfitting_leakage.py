"""Thinking in Scenarios — Lab 9. Run: python lab09_overfitting_leakage.py"""
import numpy as np

# --- Overfitting demonstration ---
rng = np.random.default_rng(5)
x = np.linspace(0, 10, 60)
y = 2 + 0.5 * x + rng.normal(0, 1.5, 60)  # true linear process + noise
tr, te, ytr, yte = x[:36], x[36:48], y[:36], y[36:48]

print("=== Overfitting: polynomial fits ===")
for deg in (1, 3, 9):
    coef = np.polyfit(tr, ytr, deg)
    rmse = lambda xx, yy: float(np.sqrt(np.mean((np.polyval(coef, xx) - yy) ** 2)))
    train_rmse = rmse(tr, ytr)
    test_rmse = rmse(te, yte)
    gap = abs(test_rmse - train_rmse)
    print(f"  degree {deg}: train {train_rmse:5.2f}   test {test_rmse:7.2f}   gap {gap:7.2f}")

# --- Leakage demonstration ---
leak = yte + rng.normal(0, 0.1, len(te))
leak_rmse = float(np.sqrt(np.mean((leak - yte) ** 2)))
print(f"\n=== Leakage ===")
print(f"  Leaked feature 'test RMSE' = {leak_rmse:.2f}")
print(f"  (vs. true model test RMSE ≈ 1.5)")
print(f"  Ratio: {1.5 / leak_rmse:.0f}× better than the true model could achieve")
print(f"  Verdict: fake skill — the feature is being told the answer.")

# --- The train/test gap as diagnostic ---
print("\n=== Diagnostic: the train/test gap ===")
for deg in (1, 3, 9):
    coef = np.polyfit(tr, ytr, deg)
    rmse = lambda xx, yy: float(np.sqrt(np.mean((np.polyval(coef, xx) - yy) ** 2)))
    gap = abs(rmse(te, yte) - rmse(tr, ytr))
    flag = "OK" if gap < 1.0 else "SUSPICIOUS" if gap < 10 else "OVERFIT"
    print(f"  degree {deg}: gap {gap:7.2f}   → {flag}")
