"""Thinking in Scenarios — Lab 8. Run: python lab08_regret.py"""
import pandas as pd

# Scenario NPV table (from Lab 6 output)
df_scen = pd.DataFrame({
    "A full entry": [26.29, 3.92, -18.78],
    "B staged naive": [16.43, -0.15, -16.98],
    "C defer": [16.19, 0.33, -15.77],
}, index=["Tailwind", "Middle", "Squeeze"])

regret = df_scen.apply(lambda col: df_scen.max(axis=1) - col)
print("Regret table (rows = scenarios):")
print(regret.round(2).to_string())

print("\nMax regret per option:")
print(regret.max().round(2).to_dict())

print(f"\nMinimax regret option: {regret.max().idxmin()}")
