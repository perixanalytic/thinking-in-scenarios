"""Thinking in Scenarios — Lab 3. Run: python lab03_bayes_pilot_signal.py"""
import numpy as np

# Meridian's scenario drivers (from Part I, Table 1.3)
SCEN = {
    "Tailwind": dict(M=480.0, s=0.12, g=0.35),
    "Middle":   dict(M=400.0, s=0.09, g=0.34),
    "Squeeze":  dict(M=280.0, s=0.05, g=0.30),
}

# The NPV function from Part I
R, YEARS = 0.10, 5
RAMP = np.array([0.30, 0.60, 1.0, 1.0, 1.0])
FIXED, INVEST = 6.5, 6.0

def npv_full_entry(M, s, g):
    gross = np.asarray(M * s * g, dtype=float)
    cf = gross[..., None] * RAMP - FIXED
    return -INVEST + np.sum(cf / (1 + R) ** np.arange(1, YEARS + 1), axis=-1)

# Bayesian update
prior = np.array([0.25, 0.50, 0.25])   # Tailwind, Middle, Squeeze
mus   = np.array([0.12, 0.09, 0.05])   # expected pilot share per scenario
sigma = 0.015                          # observation noise (1.5 pp)
obs   = 0.078                          # the pilot city's report

lik = np.exp(-0.5 * ((obs - mus) / sigma) ** 2)
post = prior * lik
post = post / post.sum()

print("Bayesian update on pilot signal (obs = 7.8%):")
for name, p0, p1 in zip(["Tailwind", "Middle", "Squeeze"], prior, post):
    print(f"  {name:9s} prior {p0:.2f} -> posterior {p1:.3f}")

print(f"\nPosterior odds Middle:Squeeze = {post[1] / post[2]:.1f}")

# Expected NPV of full entry, before and after the signal
def e_npv_full(probs):
    return sum(p * npv_full_entry(**SCEN[name]) for p, name in zip(probs, SCEN))

ev_prior = e_npv_full(prior)
ev_post  = e_npv_full(post)
print(f"\nE[NPV | full entry] on priors  = {ev_prior:6.2f}")
print(f"E[NPV | full entry] on posterior = {ev_post:6.2f}")
print(f"Revaluation from the signal      = {ev_post - ev_prior:+.2f}")

# Likelihood ratios (posterior/prior)
print("\nLikelihood ratios (posterior/prior):")
for name, p0, p1 in zip(["Tailwind", "Middle", "Squeeze"], prior, post):
    print(f"  {name:9s} ratio = {p1 / p0:5.2f}")
