"""Thinking in Scenarios — Lab 7. Run: python lab07_tornado.py"""
# Lab 7 continues from Lab 6 in the book; these are Lab 6's definitions.
import numpy as np
R, YEARS = 0.10, 5
RAMP = np.array([0.30, 0.60, 1.0, 1.0, 1.0])
FIXED, INVEST = 6.5, 6.0

import numpy as np

SCEN = {
    "Tailwind": dict(M=480.0, s=0.12, g=0.35),
    "Middle":   dict(M=400.0, s=0.09, g=0.34),
    "Squeeze":  dict(M=280.0, s=0.05, g=0.30),
}

def npv_full_entry(M, s, g, fixed=FIXED, invest=INVEST, ramp=RAMP, r=R):
    gross = M * s * g
    cf = gross * np.asarray(ramp) - fixed
    return -invest + np.sum(cf / (1 + r) ** np.arange(1, YEARS + 1))

# Tornado: each driver moved to its Squeeze and Tailwind values, others at Middle
base = npv_full_entry(**SCEN["Middle"])
print(f"Base (Middle) NPV = {base:.2f}\n")

tornado = {}
for drv in ("M", "s", "g"):
    v = {}
    for n in ("Squeeze", "Tailwind"):
        d = dict(SCEN["Middle"]); d[drv] = SCEN[n][drv]
        v[n] = npv_full_entry(**d)
    tornado[drv] = v

# Fixed cost: ±20% around its Middle value
tornado["F"] = {
    "Squeeze": npv_full_entry(**SCEN["Middle"], fixed=FIXED * 1.2),
    "Tailwind": npv_full_entry(**SCEN["Middle"], fixed=FIXED * 0.8),
}

order = sorted(tornado, key=lambda k: -abs(tornado[k]["Tailwind"] - tornado[k]["Squeeze"]))
print("Driver   Squeeze   Tailwind   Swing")
for k in order:
    lo, hi = tornado[k]["Squeeze"], tornado[k]["Tailwind"]
    print(f"  {k:6s} {lo:8.2f}  {hi:8.2f}  {hi - lo:8.2f}")
print("\nSwing rank:", order)
