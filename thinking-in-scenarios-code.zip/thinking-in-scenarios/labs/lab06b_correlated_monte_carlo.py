"""Thinking in Scenarios — Lab 6, second run. Run: python lab06b_correlated_monte_carlo.py"""
import numpy as np

R, RAMP, FIXED, INVEST = 0.10, np.array([0.30, 0.60, 1.0, 1.0, 1.0]), 6.5, 6.0

def npv_full_entry(M, s, g):
    gross = np.asarray(M * s * g, dtype=float)
    cf = gross[..., None] * RAMP - FIXED
    return -INVEST + np.sum(cf / (1 + R) ** np.arange(1, 6), axis=-1)

rng = np.random.default_rng(2026)
N = 100_000
# Run 1 (the lab as first printed): drivers drawn independently
ind = npv_full_entry(rng.triangular(280, 400, 480, N), rng.triangular(0.04, 0.09, 0.14, N),
                     rng.triangular(0.30, 0.34, 0.38, N))

# Run 2: draw the scenario first (25/50/25), then each driver within +/-10% of that scenario
rng = np.random.default_rng(2026)
base = np.array([[480, 0.12, 0.35], [400, 0.09, 0.34], [280, 0.05, 0.30]])
k = rng.choice(3, size=N, p=[0.25, 0.50, 0.25])
draw = [rng.triangular(base[k, j] * 0.9, base[k, j], base[k, j] * 1.1) for j in range(3)]
cor = npv_full_entry(*draw)

print(f"{'':22s}{'independent':>12s}{'correlated':>12s}")
for label, f in (("E[NPV]", np.mean), ("Median", np.median), ("Std dev", np.std),
                 ("P5", lambda v: np.percentile(v, 5)), ("P95", lambda v: np.percentile(v, 95))):
    print(f"{label:22s}{f(ind):12.2f}{f(cor):12.2f}")
print(f"{'P(NPV < 0)':22s}{(ind < 0).mean():12.1%}{(cor < 0).mean():12.1%}")
print(f"{'P(NPV < -10)':22s}{(ind < -10).mean():12.1%}{(cor < -10).mean():12.1%}")
