"""Thinking in Scenarios — Lab 15A. Run: python lab15a_independent_estimates.py"""
import numpy as np

rng = np.random.default_rng(15)
truth, sd, reps = 0.09, 0.025, 20_000          # true steady-state share; each manager's error

def room(n, rho=0.0, pull=0.0):
    """n estimates; rho = share of error that is common (same data); pull = drift toward first speaker."""
    common = rng.normal(0, sd * np.sqrt(rho), (reps, 1))
    est = truth + common + rng.normal(0, sd * np.sqrt(1 - rho), (reps, n))
    est[:, 1:] = pull * est[:, [0]] + (1 - pull) * est[:, 1:]
    return np.sqrt(np.mean((est.mean(axis=1) - truth) ** 2))

one = room(1)
print(f"One manager, alone:                       RMSE {one * 100:.2f} share points")
for label, kw in (("12 independent, written first", {}), ("12 sharing one consultant (rho 0.3)", {"rho": 0.3}),
                  ("12 in an anchored meeting", {"rho": 0.3, "pull": 0.6})):
    r = room(12, **kw)
    print(f"{label:40s}  RMSE {r * 100:.2f}   worth {(one / r) ** 2:4.1f} independent estimates")
print(f"\nFormula check: n_eff = n / (1 + (n-1)·rho) = {12 / (1 + 11 * 0.3):.1f} for n = 12, rho = 0.3")
