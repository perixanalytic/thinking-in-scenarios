"""Thinking in Scenarios — Lab 4. Run: python lab04_model_claims_test.py"""
import numpy as np

R, YEARS = 0.10, 5
FIXED, INVEST = 6.5, 6.0

def npv_full_entry(M, s, g, ramp, fixed=FIXED, invest=INVEST, r=R, offset=0):
    """NPV with configurable ramp and period offset (offset=0 is correct)."""
    gross = M * s * g
    cf = gross * np.asarray(ramp) - fixed
    periods = np.arange(1 + offset, YEARS + 1 + offset)
    return -invest + np.sum(cf / (1 + r) ** periods)

# Base case (Middle scenario, correct ramp)
M, s, g = 400.0, 0.09, 0.34
ramp_orig = [0.30, 0.60, 1.0, 1.0, 1.0]
ramp_rev  = [0.35, 0.45, 1.0, 1.0, 1.0]

base = npv_full_entry(M, s, g, ramp_orig)
PV_F = FIXED * np.sum(1 / (1 + R) ** np.arange(1, YEARS + 1))   # PV of five years of fixed cost
print("=== Sanity checks ===")
print(f"Base (Middle, correct ramp)             : {base:7.2f}")
print(f"Zero share                              : {npv_full_entry(M, 0, g, ramp_orig):7.2f}  (should be {-INVEST - PV_F:.2f} = -investment - PV of F)")
print(f"Zero margin                             : {npv_full_entry(M, s, 0, ramp_orig):7.2f}  (should be {-INVEST - PV_F:.2f})")
print(f"Double fixed cost                       : {npv_full_entry(M, s, g, ramp_orig, fixed=2*FIXED):7.2f}  (should be {base - PV_F:.2f} = base - PV of F)")

print("\n=== The off-by-one error (first cash flow discounted by zero periods) ===")
inflated = npv_full_entry(M, s, g, ramp_orig, offset=-1)
print(f"Correct indexing (offset=0)             : {base:7.2f}")
print(f"Discounting from t=0 (offset=-1)         : {inflated:7.2f}")
print(f"Inflation from the bug                  : {inflated - base:+.2f}  ({(inflated/base - 1):.1%})")

print("\n=== The ramp backtest ===")
print(f"Original ramp 30/60/100                 : {base:7.2f}")
print(f"Revised ramp 35/45/100                  : {npv_full_entry(M, s, g, ramp_rev):7.2f}")
print(f"Revision impact                         : {npv_full_entry(M, s, g, ramp_rev) - base:+.2f}")
