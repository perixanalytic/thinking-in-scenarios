"""Thinking in Scenarios — Lab 12. Run: python lab12_entry_game.py"""
import pandas as pd

# Payoffs in (Meridian, Incumbent) form
game = pd.DataFrame(
    {"Fight":       [(-25, -10), (-6, -4)],
     "Accommodate": [( 26,  -5), (18, -2)]},
    index=["Full entry", "Staged"])

print("The entry game (payoffs: Meridian, Incumbent):")
print(game.to_string())

# Best responses
br_m = {j: max(game.index, key=lambda i: game.loc[i, j][0]) for j in game.columns}
br_i = {i: max(game.columns, key=lambda c: game.loc[i, c][1]) for i in game.index}

print("\nMeridian best responses:")
for j in game.columns:
    print(f"  If incumbent chooses {j}: Meridian chooses {br_m[j]}")

print("\nIncumbent best responses:")
for i in game.index:
    print(f"  If Meridian chooses {i}: Incumbent chooses {br_i[i]}")

# Nash equilibria
nes = [(i, c) for i in game.index for c in game.columns
       if br_m[c] == i and br_i[i] == c]
print(f"\nNash equilibria (pure): {nes}")

# Credibility of the Fight threat
print("\n=== Credibility check: is 'Fight' a credible threat? ===")
for i in game.index:
    fight = game.loc[i, "Fight"][1]
    accom = game.loc[i, "Accommodate"][1]
    print(f"  Against {i:12s}: Fight gives {fight:+3d}, Accommodate gives {accom:+3d}")
    print(f"    → incumbent prefers {'Fight' if fight > accom else 'Accommodate'}")
print("\nVerdict: Fight is NOT credible — the incumbent prefers Accommodate in both branches.")
