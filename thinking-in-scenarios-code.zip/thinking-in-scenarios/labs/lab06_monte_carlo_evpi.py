"""Thinking in Scenarios — Lab 6. Run: python lab06_monte_carlo_evpi.py"""
import numpy as np
import pandas as pd

R, YEARS = 0.10, 5
RAMP = np.array([0.30, 0.60, 1.0, 1.0, 1.0])
FIXED, INVEST = 6.5, 6.0

def npv_full_entry(M, s, g, fixed=FIXED, invest=INVEST, ramp=RAMP, r=R):
    gross = np.asarray(M * s * g, dtype=float)
    cf = gross[..., None] * ramp - fixed
    return -invest + np.sum(cf / (1 + r) ** np.arange(1, YEARS + 1), axis=-1)

# --- Monte Carlo: 100,000 draws ---
rng = np.random.default_rng(2026)
N = 100_000
M_mc = rng.triangular(280, 400, 480, N)
s_mc = rng.triangular(0.04, 0.09, 0.14, N)
g_mc = rng.triangular(0.30, 0.34, 0.38, N)
npv_mc = npv_full_entry(M_mc, s_mc, g_mc)

print("=== Monte Carlo: full-entry NPV ===")
print(f"E[NPV]     = {npv_mc.mean():7.2f}")
print(f"Median     = {np.median(npv_mc):7.2f}")
print(f"Std dev    = {npv_mc.std():7.2f}")
print(f"P(NPV < 0) = {(npv_mc < 0).mean():.1%}")
for q in (5, 25, 75, 95):
    print(f"P{q:2d}        = {np.percentile(npv_mc, q):7.2f}")

# --- Scenario table (for the EVPI) ---
SCEN = {
    "Tailwind": dict(M=480.0, s=0.12, g=0.35),
    "Middle":   dict(M=400.0, s=0.09, g=0.34),
    "Squeeze":  dict(M=280.0, s=0.05, g=0.30),
}
SCEN_PROBS = {"Tailwind": 0.25, "Middle": 0.50, "Squeeze": 0.25}

# Column A is computed by the model above. Columns B (naive staged) and C (defer)
# are the strategy values used in Part VI (Lab 11), entered here as data so that the
# EVPI can be computed before the decision tree is introduced.
A = [float(npv_full_entry(**SCEN[n])) for n in SCEN]
df_scen = pd.DataFrame({
    "A full entry": A,
    "B naive":      [16.43, -0.15, -16.98],
    "C defer":      [16.19,  0.33, -15.77],
}, index=list(SCEN))

print("\n=== Scenario table (for EVPI) ===")
print(df_scen.round(2).to_string())

# --- EVPI ---
best_per_scen = df_scen.max(axis=1)
evpi_ev = sum(SCEN_PROBS[s] * best_per_scen[s] for s in SCEN)
ev_best_blind = max(sum(SCEN_PROBS[s] * df_scen.loc[s, c] for s in SCEN)
                    for c in df_scen.columns)
evpi = evpi_ev - ev_best_blind

print(f"\nBest blind strategy E[NPV]      = {ev_best_blind:6.2f}")
print(f"E[NPV] with scenario knowledge  = {evpi_ev:6.2f}")
print(f"EVPI (ceiling on information)   = {evpi:6.2f}")
