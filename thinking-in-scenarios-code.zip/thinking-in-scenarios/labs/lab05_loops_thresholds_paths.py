"""Thinking in Scenarios — Lab 5. Run: python lab05_loops_thresholds_paths.py"""
import numpy as np

R, FIXED, INVEST = 0.10, 6.5, 6.0

def npv_from_ramp(M, s, g, ramp, fixed=FIXED, invest=INVEST, r=R):
    gross = M * s * g
    cf = gross * np.asarray(ramp) - fixed
    return -invest + np.sum(cf / (1 + r) ** np.arange(1, len(ramp) + 1))

M, s, g = 400.0, 0.09, 0.34

# Two trajectories, same endpoints (35%, 45%, 100%, 100%, 100%)
ramp_smooth = [0.30, 0.60, 1.0, 1.0, 1.0]     # steady build
ramp_relapse = [0.30, 0.20, 1.0, 1.0, 1.0]    # relapse in year 2, recover in year 3

print("=== Same parameters, different paths ===")
print(f"Smooth build  30/60/100: NPV = {npv_from_ramp(M, s, g, ramp_smooth):7.2f}")
print(f"Relapse       30/20/100: NPV = {npv_from_ramp(M, s, g, ramp_relapse):7.2f}")
print(f"Path-dependence gap:      {npv_from_ramp(M, s, g, ramp_relapse) - npv_from_ramp(M, s, g, ramp_smooth):+.2f}")

print("\n=== The break-even cliff: Squeeze's annual contribution by year ===")
M_sq, s_sq, g_sq = 280.0, 0.05, 0.30
ramp_sq = [0.30, 0.60, 1.0, 1.0, 1.0]
for year, ramp in enumerate(ramp_sq, 1):
    gross = M_sq * s_sq * g_sq * ramp
    net = gross - FIXED
    print(f"  Year {year}: gross {gross:5.2f} − fixed {FIXED:.2f} = {net:+6.2f}")

s_be_squeeze = FIXED / (M_sq * g_sq)
s_be_middle  = FIXED / (M * g)
print(f"\nBreak-even share at Squeeze (M={M_sq:.0f}, g={g_sq:.2f}): {s_be_squeeze:.2%}")
print(f"Break-even share at Middle  (M={M:.0f}, g={g:.2f}): {s_be_middle:.2%}")
print(f"Squeeze's assumed share: {s_sq:.2%}  →  below break-even in every year")
