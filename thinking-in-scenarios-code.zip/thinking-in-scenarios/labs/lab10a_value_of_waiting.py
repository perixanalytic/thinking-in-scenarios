"""Thinking in Scenarios — Lab 10A. Run: python lab10a_value_of_waiting.py"""
import numpy as np

R, FIXED, INVEST = 0.10, 6.5, 6.0
SCEN = np.array([[480, 0.12, 0.35], [400, 0.09, 0.34], [280, 0.05, 0.30]])   # Tailwind, Middle, Squeeze
PRIOR = np.array([0.25, 0.50, 0.25])
A_EV, B_EV = 3.84, 2.93          # full entry; staged with exit rule (exact solution of Lab 10's tree)

def defer_entry(M, s, g, kept=1.0):
    """Wait a year, then enter: 6.0 at t=1, four operating years. kept<1 = share eroded while waiting."""
    cf = M * s * kept * g * np.array([0.30, 0.60, 1.0, 1.0]) - FIXED
    return -INVEST / (1 + R) + np.sum(cf / (1 + R) ** np.arange(2, 6))

def defer_and_learn(sigma_M=40.0, erosion=0.0, cost=0.3):
    """Wait, buy a study that reads market size M with noise sigma_M, enter only if E[value | study] >= 0."""
    vals = np.array([defer_entry(*sc, kept=1 - erosion) for sc in SCEN])
    x = np.linspace(0, 800, 6001); dx = x[1] - x[0]
    lik = np.exp(-0.5 * ((x[:, None] - SCEN[:, 0]) / sigma_M) ** 2)
    post = PRIOR * lik / (PRIOR * lik).sum(axis=1, keepdims=True)
    enter = (post * vals).sum(axis=1) >= 0
    p_enter = (lik / (sigma_M * np.sqrt(2 * np.pi)) * enter[:, None]).sum(axis=0) * dx
    return float(PRIOR @ (p_enter * vals) - cost), p_enter

static = np.array([defer_entry(*sc) for sc in SCEN])
print("C as first priced (wait, then enter regardless):", np.round(static, 2), f"E = {PRIOR @ static:.2f}")

print("\nDefer-and-learn (study cost 0.3, sigma_M = 40):")
for e in (0.0, 0.05, 0.10, 0.15):
    ev, p = defer_and_learn(erosion=e)
    print(f"  erosion {e:4.0%}: E[NPV] = {ev:5.2f}   P(enter | Tailwind, Middle, Squeeze) = {np.round(p, 3)}"
          f"   P(path below -10) = {PRIOR[2] * p[2]:.2%}")

# Where does waiting stop paying?
grid = np.linspace(0, 0.2, 2001)
ev40 = np.array([defer_and_learn(erosion=e)[0] for e in grid])
print(f"\nBreak-even erosion vs staged ({B_EV}):   {grid[np.argmin(np.abs(ev40 - B_EV))]:.1%}")
print(f"Break-even erosion vs full entry ({A_EV}): {'none - it never quite catches A' if ev40.max() < A_EV else grid[np.argmin(np.abs(ev40 - A_EV))]}")
print(f"Each point of erosion costs about {(ev40[0] - ev40[1000]) / 10:.2f}")
ev80, _ = defer_and_learn(sigma_M=80.0)
print(f"\nWith a weak study (sigma_M = 80) and no erosion: {ev80:.2f}")

# The pilot's foothold: how much of the region-wide position does it protect while Meridian learns?
SIG, MUS = 0.015, np.array([0.12, 0.09, 0.05])

def staged_value(erosion_on_rollout):
    """Lab 10's tree, solved exactly, with the region-wide roll-out's share eroded by the given amount."""
    pilot = np.array([-2.5 + (M * s * g * 0.10 - 1.0) / (1 + R) for M, s, g in SCEN])
    proceed = np.array([-4.0 / (1 + R) + np.sum((M * s * (1 - erosion_on_rollout) * g * np.array([0.30, 0.60, 1.0, 1.0]) - FIXED)
                        / (1 + R) ** np.arange(2, 6)) for M, s, g in SCEN])
    x = np.linspace(-0.05, 0.25, 6001); dx = x[1] - x[0]
    lik = np.exp(-0.5 * ((x[:, None] - MUS) / SIG) ** 2)
    go = ((PRIOR * lik) @ proceed) >= 0
    p_go = (lik / (SIG * np.sqrt(2 * np.pi)) * go[:, None]).sum(axis=0) * dx
    return float(PRIOR @ (pilot + p_go * proceed))

E_BELIEF = 0.10
learn10, _ = defer_and_learn(erosion=E_BELIEF)
print(f"\nAt the board's believed erosion of {E_BELIEF:.0%}: defer-and-learn = {learn10:.2f}")
for protect in (1.0, 0.75, 0.5, 0.0):
    print(f"  staged, pilot protects {protect:4.0%} of the position: {staged_value(E_BELIEF * (1 - protect)):5.2f}")
f = np.linspace(0, 1, 1001)
vals = np.array([staged_value(E_BELIEF * (1 - x)) for x in f])
print(f"Staged beats defer-and-learn only if the pilot protects at least {f[np.argmax(vals >= learn10)]:.0%} of the position")
