"""Thinking in Scenarios — Lab 15. Run: python lab15_decision_portfolio.py"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(31)
dec = pd.DataFrame({
    "decision": [f"D{i+1:02d}" for i in range(12)],
    "process":  rng.uniform(0.3, 0.95, 12),
    "outcome":  rng.normal(0, 1, 12),
})
print("=== Twelve past decisions ===")
print(dec.round(2).to_string(index=False))

corr = dec["process"].corr(dec["outcome"])
print(f"\nCorrelation process-outcome (small sample): {corr:+.2f}")

# Decompose: is this correlation just noise?
n = len(dec)
# Under the null (no true process-outcome relationship), what is the sampling distribution of the correlation?
null_corrs = []
for _ in range(10_000):
    fake = rng.normal(0, 1, n)
    null_corrs.append(np.corrcoef(dec["process"], fake)[0, 1])
null_corrs = np.array(null_corrs)
print(f"\nUnder the null (no relationship), the correlation is:")
print(f"  Mean: {null_corrs.mean():+.3f}")
print(f"  Std:  {null_corrs.std():.3f}")
print(f"  95% CI: [{np.percentile(null_corrs, 2.5):+.3f}, {np.percentile(null_corrs, 97.5):+.3f}]")
print(f"  Observed correlation ({corr:+.2f}) is {'inside' if abs(corr) < np.percentile(np.abs(null_corrs), 95) else 'OUTSIDE'} the null's 95% range.")
print("\nVerdict: with n=12, a correlation of -0.23 is fully compatible with the null hypothesis.")
print("The negative correlation is a small-sample artefact, not a verdict on process.")
