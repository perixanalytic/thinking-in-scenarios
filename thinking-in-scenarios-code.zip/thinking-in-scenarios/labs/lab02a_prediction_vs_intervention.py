"""Thinking in Scenarios — Lab 2A. Run: python lab02a_prediction_vs_intervention.py"""
import numpy as np

rng = np.random.default_rng(21)
n = 40_000
loyalty = rng.beta(2, 2, n)                                   # home-market shoppers
p_buy = 1 / (1 + np.exp(-(-2.2 + 4.4 * loyalty)))             # baseline purchase probability
# The voucher's causal effect: biggest for the middle of the loyalty range, slightly
# negative for the most loyal (they buy anyway; a discount cheapens the brand).
uplift = 0.16 * np.exp(-((loyalty - 0.42) / 0.18) ** 2) - 0.04 * (loyalty > 0.80)

# 1. History: marketing handed vouchers mostly to loyal shoppers.
gave = rng.random(n) < 1 / (1 + np.exp(-(-3 + 6 * loyalty)))
bought = rng.random(n) < np.clip(p_buy + uplift * gave, 0, 1)
naive = bought[gave].mean() - bought[~gave].mean()

# 2. Experiment: vouchers assigned by coin flip.
coin = rng.random(n) < 0.5
bought_rct = rng.random(n) < np.clip(p_buy + uplift * coin, 0, 1)
rct = bought_rct[coin].mean() - bought_rct[~coin].mean()

print(f"Voucher effect from historical data:  {naive:+.3f}")
print(f"Voucher effect from the experiment:   {rct:+.3f}")
print(f"True average effect (simulation):     {uplift.mean():+.3f}")

# 3. Whom to treat? Rank loyalty deciles two ways, using the experiment's data.
edges = np.quantile(loyalty, np.linspace(0, 1, 11))
dec = np.clip(np.searchsorted(edges, loyalty, side="right") - 1, 0, 9)
buy_rate = np.array([bought_rct[dec == d].mean() for d in range(10)])
lift = np.array([bought_rct[(dec == d) & coin].mean() - bought_rct[(dec == d) & ~coin].mean() for d in range(10)])
true_lift = np.array([uplift[dec == d].mean() for d in range(10)])
MARGIN, COST = 4.0, 0.25                                      # per incremental purchase / per voucher

def profit(order, k):                                         # per 1,000 shoppers, treating top-k deciles
    return 1000 * sum(true_lift[d] * MARGIN - COST for d in order[:k]) / 10

for name, order in (("predicted purchase", np.argsort(-buy_rate)), ("measured uplift", np.argsort(-lift))):
    best_k = max(range(11), key=lambda k: profit(order, k))
    print(f"\nRank by {name:18s}: treat top 30% -> {profit(order, 3):+5.0f}; "
          f"best is top {best_k * 10}% -> {profit(order, best_k):+5.0f} per 1,000 shoppers")
print(f"\nTreat everyone: {profit(np.arange(10), 10):+.0f} per 1,000 shoppers")
print("Measured uplift by loyalty decile:", np.round(lift, 3))
