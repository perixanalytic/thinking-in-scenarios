"""Thinking in Scenarios — Lab 2. Run: python lab02_simpsons_paradox.py"""
import pandas as pd

# Incumbent's share and category volume (index) by district type and segment
data = pd.DataFrame({
    "district_income": ["low", "low", "high", "high"],
    "segment":         ["premium", "standard", "premium", "standard"],
    "incumbent_share": [0.15, 0.45, 0.20, 0.50],
    "volume":          [10, 90, 70, 30],
})

# The aggregate: pool the segments, weighting each by its volume
data["incumbent_volume"] = data["incumbent_share"] * data["volume"]
agg = data.groupby("district_income")[["incumbent_volume", "volume"]].sum()
agg["incumbent_share"] = agg["incumbent_volume"] / agg["volume"]
print("Aggregate view (all segments pooled):")
print(agg["incumbent_share"].round(2).to_string())

# The segments, held apart
within = data.pivot(index="segment", columns="district_income", values="incumbent_share")
print("\nWithin segments:")
print(within[["low", "high"]].to_string())

# The mix that does the damage
mix = data.pivot(index="segment", columns="district_income", values="volume")
print("\nSegment mix (share of district volume):")
print((mix / mix.sum())[["low", "high"]].round(2).to_string())
