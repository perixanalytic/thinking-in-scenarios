"""Thinking in Scenarios — Lab 11A. Run: python lab11a_weight_perturbation.py"""
import numpy as np

w = np.array([0.35, 0.25, 0.15, 0.15, 0.10])
benefit = np.array([True, True, False, False, False])
naive = np.array([[3.84, -18.78, 0.25, 30, 4.0],      # A
                  [-0.21, -16.98, 0.75, 18, 3.0],     # B naive
                  [0.27, -15.77, 0.25, 6, 1.5]])      # C
revised = naive.copy(); revised[1, 0] = 2.91          # B as strategy

def normalise(m):
    lo, hi = m.min(axis=0), m.max(axis=0)
    return np.where(benefit, m - lo, hi - m) / (hi - lo)

def topsis(m, w):
    v = normalise(m) * w
    return np.linalg.norm(v - v.min(0), axis=1) / (np.linalg.norm(v - v.max(0), axis=1) + np.linalg.norm(v - v.min(0), axis=1))

rng = np.random.default_rng(611)
W = rng.dirichlet(40 * w, 4000)                        # 4,000 weight sets centred on the board's
for name, m in (("naive", naive), ("revised", revised)):
    ws = np.bincount((normalise(m) @ W.T).argmax(axis=0), minlength=3) / 4000
    tp = np.bincount([topsis(m, x).argmax() for x in W], minlength=3) / 4000
    print(f"{name:8s} weighted sum wins  A {ws[0]:4.0%}  B {ws[1]:4.0%}  C {ws[2]:4.0%}")
    print(f"{'':8s} TOPSIS wins        A {tp[0]:4.0%}  B {tp[1]:4.0%}  C {tp[2]:4.0%}")
print("\nNaive weighted sum at the stated weights:", np.round(normalise(naive) @ w, 3))
print("Naive TOPSIS at the stated weights:      ", np.round(topsis(naive, w), 3))
