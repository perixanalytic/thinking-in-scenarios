"""Thinking in Scenarios — Lab 9A. Run: python lab09a_drift.py"""
import numpy as np

rng = np.random.default_rng(9)
months, shift = 60, 40
t = np.arange(1, months + 1)
gap = 0.15 + 0.05 * np.sin(t / 5) + rng.normal(0, 0.02, months)   # Meridian's price premium
ramp = np.clip((t - shift) / 14, 0, 1)        # from month 40 the incumbent matches promotions:
gap = gap + 0.06 * ramp                        #   the premium widens a little...
beta = -20.0 - 20.0 * ramp                     #   ...and customers become twice as price-sensitive
sales = 10 + beta * gap + 0.04 * t + rng.normal(0, 0.45, months)

# The model: trained and validated on months 1-36, then deployed
train = t <= 36
X = np.column_stack([np.ones(months), gap, t])
coef, *_ = np.linalg.lstsq(X[train], sales[train], rcond=None)
err = sales - X @ coef
sd = err[train].std(ddof=3)
print(f"Training error (MAE, months 1-36):      {np.abs(err[train]).mean():.2f}")
print(f"Deployed error (MAE, months 45-60):     {np.abs(err[44:]).mean():.2f}")

# Monitor 1 — inputs: is the price gap outside the range the model was trained on?
lo, hi = gap[train].min(), gap[train].max()
outside = t[(gap < lo) | (gap > hi)]
print(f"Input monitor: months outside training range: {[int(m) for m in outside]}")

# Monitor 2 — outcomes: one-sided CUSUM on standardised under-forecasts
k, h, c, alarm = 0.5, 4.0, 0.0, None
for i in range(36, months):
    c = max(0.0, c + (-err[i] / sd) - k)
    if alarm is None and c > h:
        alarm = t[i]
print(f"Outcome monitor (CUSUM, h = {h}): alarm in month {alarm}, {alarm - shift} months after the shift began")
