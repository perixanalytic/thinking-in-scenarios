"""Thinking in Scenarios — Lab 13. Run: python lab13_signposts.py"""
import numpy as np

SIGMA = 0.015
MUS = np.array([0.12, 0.09, 0.05])   # Tailwind, Middle, Squeeze
PRIOR = np.array([0.25, 0.50, 0.25])

# The decision rule: proceed if E[proceed NPV | signal] >= 0
PROCEED_NPV = np.array([18.01, 2.15, -13.96])

def posterior_expected_proceed(x):
    lik = np.exp(-0.5 * ((x - MUS) / SIGMA) ** 2)
    post = PRIOR * lik
    post = post / post.sum()
    return (post * PROCEED_NPV).sum(), post

# Find the tripwire (the signal at which E[proceed NPV] = 0)
xs = np.linspace(0.04, 0.13, 2000)
evs = np.array([posterior_expected_proceed(x)[0] for x in xs])
crossing = xs[np.argmin(np.abs(evs))]
print(f"=== The tripwire (from the model) ===")
print(f"E[proceed NPV] crosses zero at x ≈ {crossing:.3%}")
print(f"(The team's chosen tripwire of 6.5% is a conservative threshold below the crossing.)")

# Simulate a year of monitoring under the signpost system
def simulate_year(seed, n=50_000):
    rng = np.random.default_rng(seed)
    scen = rng.choice(3, size=n, p=PRIOR)
    signal = MUS[scen] + rng.normal(0, SIGMA, n)
    repeat_purch = rng.normal(0.33, 0.06, n)         # in % terms
    incumbent_cut = rng.random(n) < 0.05            # 5% chance of a cut > 8%
    tripwire_fired = signal < 0.065
    sp2_fired = repeat_purch < 0.30
    sp3_fired = incumbent_cut
    return scen, signal, tripwire_fired, sp2_fired, sp3_fired

scen, signal, tw, sp2, sp3 = simulate_year(seed=42)
print(f"\n=== Signpost firing rates (50,000 simulated years) ===")
print(f"Tripwire (share < 6.5%):   {tw.mean():.1%}")
print(f"Signpost 2 (repeat < 30%): {sp2.mean():.1%}")
print(f"Signpost 3 (incumbent cut): {sp3.mean():.1%}")

print(f"\n=== Tripwire firing by true scenario ===")
for i, name in enumerate(["Tailwind", "Middle", "Squeeze"]):
    rate = tw[scen == i].mean()
    print(f"  True {name:9s}: {rate:.1%}")

print(f"\n=== Is the tripwire well-calibrated? ===")
# If the tripwire fires, the posterior's expected proceed-NPV should be negative
fired_ev = np.array([posterior_expected_proceed(x)[0] for x in signal[tw][:100]])
print(f"  When the tripwire fires, E[proceed NPV | signal] should be < 0.")
print(f"  Mean E[proceed NPV | tripwire fired] = {fired_ev.mean():.2f}")
