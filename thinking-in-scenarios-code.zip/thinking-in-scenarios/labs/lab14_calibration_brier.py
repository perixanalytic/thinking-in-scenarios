"""Thinking in Scenarios — Lab 14. Run: python lab14_calibration_brier.py"""
import numpy as np

rng = np.random.default_rng(88)
n = 200
p_true = rng.uniform(0.1, 0.9, n)
outcomes = rng.random(n) < p_true

# Calibrated forecaster: stated probability ≈ true probability + small noise
p_cal = np.clip(p_true + rng.normal(0, 0.05, n), 0.02, 0.98)

# Overconfident forecaster: extremises (pushes away from 0.5)
p_over = np.clip(0.5 + (p_true - 0.5) * 1.8 + rng.normal(0, 0.05, n), 0.02, 0.98)

brier = lambda p: float(np.mean((p - outcomes * 1.0) ** 2))
print("=== Brier scores ===")
print(f"  Calibrated:    {brier(p_cal):.3f}")
print(f"  Overconfident: {brier(p_over):.3f}")
print(f"  (Lower is better; perfect = 0.000; always-50% = 0.250)")

print("\n=== Calibration curves ===")
for name, p in [("Calibrated", p_cal), ("Overconfident", p_over)]:
    print(f"\n{name}:")
    print(f"  {'Stated':>10s}  {'Observed':>10s}  {'N':>5s}")
    for lo in np.arange(0, 1, 0.2):
        m = (p >= lo) & (p < lo + 0.2)
        if m.sum() > 0:
            stated = (lo + lo + 0.2) / 2
            observed = outcomes[m].mean()
            print(f"  {stated:>9.2f}  {observed:>10.2f}  {m.sum():>5d}")

# Compute the mean calibration error
print("\n=== Mean absolute calibration error ===")
for name, p in [("Calibrated", p_cal), ("Overconfident", p_over)]:
    errors = []
    for lo in np.arange(0, 1, 0.2):
        m = (p >= lo) & (p < lo + 0.2)
        if m.sum() > 0:
            stated = (lo + lo + 0.2) / 2
            observed = outcomes[m].mean()
            errors.append(abs(stated - observed))
    print(f"  {name:14s}: {np.mean(errors):.3f}")
