"""Thinking in Scenarios — Lab 1. Run: python lab01_process_vs_luck.py"""
import numpy as np

def run_cohort(p_win, n=200, t=50, seed=11):
    rng = np.random.default_rng(seed)
    wins = rng.random((n, t)) < p_win
    return 2 * wins.sum(axis=1) - t  # +1 per win, -1 per loss

good = run_cohort(0.60)
bad = run_cohort(0.40)

print(f"Good process: mean {good.mean():+.1f}, share ahead {(good > 0).mean():.0%}")
print(f"Bad process:  mean {bad.mean():+.1f}, share ahead {(bad > 0).mean():.0%}")
print(f"Bad-process managers who ended ahead: {(bad > 0).sum()} of {len(bad)}")
