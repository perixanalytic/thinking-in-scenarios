"""Thinking in Scenarios — Lab 10. Run: python lab10_decision_tree.py"""
import numpy as np

R, YEARS = 0.10, 5
FIXED, INVEST = 6.5, 6.0
RAMP = np.array([0.30, 0.60, 1.0, 1.0, 1.0])
SIGMA, PRIOR_MUS = 0.015, np.array([0.12, 0.09, 0.05])
PRIOR = np.array([0.25, 0.50, 0.25])

SCEN = {
    "Tailwind": dict(M=480.0, s=0.12, g=0.35),
    "Middle":   dict(M=400.0, s=0.09, g=0.34),
    "Squeeze":  dict(M=280.0, s=0.05, g=0.30),
}

def npv_full(M, s, g):
    gross = M * s * g
    cf = gross * RAMP - FIXED
    return -INVEST + np.sum(cf / (1 + R) ** np.arange(1, YEARS + 1))

def staged_components(M, s, g):
    gross = M * s * g
    pilot = -2.5 + (gross * 0.10 - 1.0) / (1 + R)
    cf = gross * np.array([0.30, 0.60, 1.0, 1.0]) - FIXED
    proceed = -4.0 / (1 + R) + np.sum(cf / (1 + R) ** np.arange(2, YEARS + 1))
    return pilot, proceed

# Per-scenario pilot and proceed NPV
proceed_vals = {n: staged_components(**SCEN[n])[1] for n in SCEN}
pilot_npv   = {n: staged_components(**SCEN[n])[0] for n in SCEN}

print("=== Per-scenario: pilot and proceed NPV ===")
for n in SCEN:
    print(f"  {n:9s} pilot {pilot_npv[n]:6.2f}   proceed {proceed_vals[n]:7.2f}")

# Simulate the tree
def staged_tree(seed=99, n_sim=200_000):
    r = np.random.default_rng(seed)
    scen_idx = r.choice(3, size=n_sim, p=PRIOR)
    signal = PRIOR_MUS[scen_idx] + r.normal(0, SIGMA, n_sim)
    lik = np.exp(-0.5 * ((signal[:, None] - PRIOR_MUS[None, :]) / SIGMA) ** 2)
    post = PRIOR * lik; post = post / post.sum(axis=1, keepdims=True)
    pv = np.array(list(proceed_vals.values()))[None, :]
    ev_proceed = (post * pv).sum(axis=1)
    proceed = ev_proceed >= 0
    pilot_arr = np.array(list(pilot_npv.values()))[scen_idx]
    payoff = np.where(proceed, pv[0, scen_idx], 0.0)
    total = pilot_arr + payoff
    per_scen = [float(total[scen_idx == i].mean()) for i in range(3)]
    q = np.array(list(proceed_vals.values()))
    Eq = float((PRIOR * q).sum())
    evsi = float(np.maximum(ev_proceed, 0).mean()) - max(0.0, Eq)
    return total.mean(), float((total < 0).mean()), float(total.min()), per_scen, float(proceed[scen_idx == 2].mean()), float((total < -10).mean()), evsi

enpv_smart, p_loss, worst, per_scen, p_misfire, p_cat, evsi = staged_tree()
print(f"\n=== Expected NPV of each option ===")
print(f"  B staged, adaptive abandon rule: {enpv_smart:6.2f}")
print(f"  B staged, always proceed:        {-0.21:6.2f}")
print(f"  A full entry:                    {3.84:6.2f}")
print(f"  C defer:                         {0.27:6.2f}")
print(f"  Net incremental (staged vs best blind): {enpv_smart - 3.84:+.2f}")

print(f"\n=== Cash-flow identity ===")
for n in SCEN:
    total = pilot_npv[n] + proceed_vals[n]
    print(f"  {n:9s} pilot {pilot_npv[n]:6.2f} + proceed {proceed_vals[n]:7.2f} = {total:7.2f}")

print(f"\n=== Downside diagnostics ===")
print(f"  Worst reachable outcome: {worst:7.2f}")
print(f"  P(misfire | Squeeze) = {p_misfire:.1%}")
print(f"  Overall P(NPV < -10) = {p_cat:.1%}")
print(f"  Full entry: certain -18.78 in Squeeze (P = 25%)")

print(f"\n=== Value of the pilot's signal ===")
q = np.array(list(proceed_vals.values()))
Eq = float((PRIOR * q).sum())
evpi = float((PRIOR * np.maximum(q, 0)).sum()) - max(0.0, Eq)
print(f"  E[q] on priors alone = {Eq:.2f}")
print(f"  EVSI (noisy signal)  = {evsi:.2f}")
print(f"  EVPI (perfect info)  = {evpi:.2f}")
print(f"  EVSI / EVPI          = {evsi/evpi:.0%}")
