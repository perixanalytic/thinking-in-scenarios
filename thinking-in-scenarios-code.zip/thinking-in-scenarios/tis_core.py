"""
tis_core.py — the Meridian Naturals model, in one place.

Every number in *Thinking in Scenarios* is produced from the functions below.
The labs in the book print excerpts of this file; the figure kit (tis_figures.py)
draws every chart from it. Nothing here is quoted from an unrun model.

Conventions
-----------
* Money is in $ millions; NPV at 10% over five years.
* Scenario order is always (Tailwind, Middle, Squeeze).
* Option order is always (A full entry, B staged, C defer).
* Every random draw takes an explicit seed.
"""
from __future__ import annotations

import numpy as np
from math import erf, sqrt

# ---------------------------------------------------------------------------
# 1. The driver model (Part I, Table 1.2)
# ---------------------------------------------------------------------------
R, YEARS = 0.10, 5
RAMP = np.array([0.30, 0.60, 1.0, 1.0, 1.0])
FIXED, INVEST = 6.5, 6.0

SCEN_NAMES = ("Tailwind", "Middle", "Squeeze")
SCEN = {
    "Tailwind": dict(M=480.0, s=0.12, g=0.35),
    "Middle":   dict(M=400.0, s=0.09, g=0.34),
    "Squeeze":  dict(M=280.0, s=0.05, g=0.30),
}
PRIOR = np.array([0.25, 0.50, 0.25])
PILOT_MUS = np.array([0.12, 0.09, 0.05])   # implied pilot share per scenario
SIGMA = 0.015                              # pilot observation noise (1.5 pp)
DISC = 1 / (1 + R) ** np.arange(1, YEARS + 1)


def npv_full(M, s, g, ramp=RAMP, fixed=FIXED, invest=INVEST, r=R):
    """Option A: invest 6.0 now, full fixed cost from year 1."""
    gross = np.asarray(M * s * g, dtype=float)
    cf = gross[..., None] * np.asarray(ramp) - fixed
    return -invest + np.sum(cf / (1 + r) ** np.arange(1, len(ramp) + 1), axis=-1)


def staged_components(M, s, g):
    """Option B pieces: pilot NPV (year 1) and proceed NPV (years 2-5)."""
    gross = M * s * g
    pilot = -2.5 + (gross * 0.10 - 1.0) / (1 + R)
    cf = gross * np.array([0.30, 0.60, 1.0, 1.0]) - FIXED
    proceed = -4.0 / (1 + R) + np.sum(cf / (1 + R) ** np.arange(2, YEARS + 1))
    return pilot, proceed


def defer_entry(M, s, g, share_kept=1.0):
    """Option C as the first edition priced it: wait a year, then enter regardless.
    share_kept < 1 models erosion: share the incumbent locks up while Meridian waits."""
    gross = M * s * share_kept * g
    cf = gross * np.array([0.30, 0.60, 1.0, 1.0]) - FIXED
    return -INVEST / (1 + R) + np.sum(cf / (1 + R) ** np.arange(2, YEARS + 1))


A_COL = np.array([float(npv_full(**SCEN[n])) for n in SCEN_NAMES])          # 26.29, 3.92, -18.78
PILOT = np.array([staged_components(**SCEN[n])[0] for n in SCEN_NAMES])     # -1.58, -2.30, -3.03
PROCEED = np.array([staged_components(**SCEN[n])[1] for n in SCEN_NAMES])   # 18.01, 2.15, -13.96
B_NAIVE = PILOT + PROCEED                                                   # 16.43, -0.15, -16.98
C_COL = np.array([defer_entry(**SCEN[n]) for n in SCEN_NAMES])              # 16.19, 0.33, -15.77


# ---------------------------------------------------------------------------
# 2. Belief: Bayes on the pilot signal (Part II)
# ---------------------------------------------------------------------------
def posterior(x, prior=PRIOR, mus=PILOT_MUS, sigma=SIGMA):
    """Posterior over scenarios for an observed pilot share x (scalar or array)."""
    x = np.atleast_1d(np.asarray(x, dtype=float))
    lik = np.exp(-0.5 * ((x[:, None] - mus[None, :]) / sigma) ** 2)
    post = prior * lik
    with np.errstate(invalid="ignore", divide="ignore"):    # far-tail signals: 0/0 -> nan, never used
        return post / post.sum(axis=1, keepdims=True)


def _norm_cdf(z):
    return 0.5 * (1 + np.vectorize(erf)(np.asarray(z) / sqrt(2)))


# ---------------------------------------------------------------------------
# 3. Option B as a strategy: the decision tree solved exactly (Part VI)
# ---------------------------------------------------------------------------
def staged_policy(prior=PRIOR, sigma=SIGMA, true_bias=0.0, assumed_bias=0.0,
                  pilot=PILOT, proceed=PROCEED, grid=6001):
    """Solve the proceed-or-abandon rule on a fine grid of signals.

    true_bias    : how much the pilot city flatters the signal in reality
    assumed_bias : how much the team corrects for (0 = takes the signal at face value)
    Returns dict with expected value, per-scenario expected values, P(proceed | scenario),
    the probability of the catastrophic misfire path, and the signal threshold.
    """
    xs = np.linspace(-0.05, 0.25, grid)
    dx = xs[1] - xs[0]
    post = posterior(xs, prior, PILOT_MUS + assumed_bias, sigma)
    go = (post * proceed).sum(axis=1) >= 0
    # density of the observed signal under each true scenario
    dens = np.exp(-0.5 * ((xs[:, None] - (PILOT_MUS + true_bias)) / sigma) ** 2) / (sigma * np.sqrt(2 * np.pi))
    p_go = (dens * go[:, None]).sum(axis=0) * dx
    per = pilot + p_go * proceed
    ev = float((prior * per).sum())
    thr = float(xs[np.argmax(go)]) if go.any() else np.nan
    return dict(ev=ev, per=per, p_go=p_go, threshold=thr,
                p_misfire=float(p_go[2]), p_cat=float(prior[2] * p_go[2]))


def evsi_evpi(prior=PRIOR, sigma=SIGMA):
    """Value of the pilot's signal on the proceed-or-abandon decision."""
    sol = staged_policy(prior, sigma)
    base = max(0.0, float((prior * PROCEED).sum()))
    evsi = float((prior * sol["p_go"] * PROCEED).sum()) - base
    evpi = float((prior * np.maximum(PROCEED, 0)).sum()) - base
    return evsi, evpi


# ---------------------------------------------------------------------------
# 4. Option C as a strategy: wait, study, then decide (Part VI, Section 6.2.4)
# ---------------------------------------------------------------------------
MARKET_M = np.array([480.0, 400.0, 280.0])


def defer_and_learn(sigma_M=40.0, erosion=0.0, cost=0.3, prior=PRIOR, grid=6001):
    """Wait one year, buy a market study that reads M with noise sigma_M, enter only if
    the posterior expected entry value is non-negative. Erosion = share lost while waiting."""
    vals = np.array([defer_entry(**SCEN[n], share_kept=1 - erosion) for n in SCEN_NAMES])
    if sigma_M <= 1e-6:                                     # perfect study
        p_go = (vals >= 0).astype(float)
    else:
        xs = np.linspace(0, 800, grid)
        dx = xs[1] - xs[0]
        lik = np.exp(-0.5 * ((xs[:, None] - MARKET_M) / sigma_M) ** 2)
        post = prior * lik
        post = post / post.sum(axis=1, keepdims=True)
        go = (post * vals).sum(axis=1) >= 0
        dens = lik / (sigma_M * np.sqrt(2 * np.pi))
        p_go = (dens * go[:, None]).sum(axis=0) * dx
    per = p_go * vals - cost
    return dict(ev=float((prior * per).sum()), per=per, p_go=p_go,
                p_cat=float(prior[2] * p_go[2]), static=vals)


# ---------------------------------------------------------------------------
# 5. Simulation: the fan, independent and scenario-correlated (Part IV)
# ---------------------------------------------------------------------------
def mc_independent(n=100_000, seed=2026):
    rng = np.random.default_rng(seed)
    M = rng.triangular(280, 400, 480, n)
    s = rng.triangular(0.04, 0.09, 0.14, n)
    g = rng.triangular(0.30, 0.34, 0.38, n)
    return npv_full(M, s, g)


def mc_correlated(n=100_000, seed=2026, spread=0.10):
    """Draw a scenario first (25/50/25), then each driver within +/-spread of it."""
    rng = np.random.default_rng(seed)
    idx = rng.choice(3, size=n, p=PRIOR)
    base = np.array([[SCEN[k]["M"], SCEN[k]["s"], SCEN[k]["g"]] for k in SCEN_NAMES])
    d = [rng.triangular(base[idx, j] * (1 - spread), base[idx, j], base[idx, j] * (1 + spread)) for j in range(3)]
    return npv_full(*d), idx


def fan_stats(v):
    q = np.percentile(v, [5, 25, 50, 75, 95])
    return dict(mean=float(v.mean()), sd=float(v.std()), p5=q[0], p25=q[1], median=q[2],
                p75=q[3], p95=q[4], p_loss=float((v < 0).mean()), p_cat=float((v < -10).mean()))


def tornado(base_key="Middle"):
    base = float(npv_full(**SCEN[base_key]))
    out = {}
    for drv in ("M", "s", "g"):
        lo, hi = dict(SCEN[base_key]), dict(SCEN[base_key])
        lo[drv], hi[drv] = SCEN["Squeeze"][drv], SCEN["Tailwind"][drv]
        out[drv] = (float(npv_full(**lo)), float(npv_full(**hi)))
    out["F"] = (float(npv_full(**SCEN[base_key], fixed=FIXED * 1.2)),
                float(npv_full(**SCEN[base_key], fixed=FIXED * 0.8)))
    pct = {}
    for drv in ("M", "s", "g"):
        lo, hi = dict(SCEN[base_key]), dict(SCEN[base_key])
        lo[drv] *= 0.8; hi[drv] *= 1.2
        pct[drv] = (float(npv_full(**lo)), float(npv_full(**hi)))
    pct["F"] = out["F"]
    return base, out, pct


# ---------------------------------------------------------------------------
# 6. Choosing: regret, scorecards, criteria (Parts IV and VI)
# ---------------------------------------------------------------------------
def regret(table):
    """table: rows = scenarios, cols = options."""
    table = np.asarray(table, float)
    return table.max(axis=1, keepdims=True) - table


CRITERIA = ("ENPV", "Worst case", "P(loss)", "Attention", "Brand risk")
BENEFIT = np.array([True, True, False, False, False])
WEIGHTS = np.array([0.35, 0.25, 0.15, 0.15, 0.10])
SCORE_NAIVE = np.array([[3.84, -18.78, 0.25, 30, 4.0],
                        [-0.21, -16.98, 0.75, 18, 3.0],
                        [0.27, -15.77, 0.25, 6, 1.5]])
SCORE_REVISED = SCORE_NAIVE.copy(); SCORE_REVISED[1, 0] = 2.91


def normalise(mat):
    mat = np.asarray(mat, float)
    lo, hi = mat.min(axis=0), mat.max(axis=0)
    return np.where(BENEFIT, (mat - lo), (hi - mat)) / (hi - lo)


def weighted_sum(mat, w=WEIGHTS):
    return normalise(mat) @ w


def topsis(mat, w=WEIGHTS):
    v = normalise(mat) * w
    d_best = np.linalg.norm(v - v.max(axis=0), axis=1)
    d_worst = np.linalg.norm(v - v.min(axis=0), axis=1)
    return d_worst / (d_best + d_worst)


def weight_perturbation(mat, n=4000, concentration=40, seed=611):
    """Draw weight sets from a Dirichlet centred on the board's weights; count wins."""
    rng = np.random.default_rng(seed)
    W = rng.dirichlet(concentration * WEIGHTS, n)
    ws_wins = np.bincount(np.argmax(normalise(mat) @ W.T, axis=0), minlength=3) / n
    tp_wins = np.bincount([int(np.argmax(topsis(mat, w))) for w in W], minlength=3) / n
    return ws_wins, tp_wins


def hurwicz(best, worst, alpha):
    return alpha * np.asarray(best) + (1 - alpha) * np.asarray(worst)


# ---------------------------------------------------------------------------
# 7. Deep uncertainty: when the probabilities themselves are contested (Section 4.7)
# ---------------------------------------------------------------------------
def simplex_grid(step=0.01):
    """All (pT, pM, pS) on a grid of the probability simplex."""
    pts = []
    k = int(round(1 / step))
    for i in range(k + 1):
        for j in range(k + 1 - i):
            pts.append((i * step, j * step, 1 - (i + j) * step))
    return np.clip(np.array(pts), 0, 1)


def option_values_under(prior, erosion=0.05, sigma_M=40.0):
    """Expected value of A, B (re-solved tree), C (static), C-learn for one prior."""
    prior = np.asarray(prior, float)
    a = float(prior @ A_COL)
    b = staged_policy(prior=prior, grid=1501)["ev"] if prior.min() >= 0 else np.nan
    c = float(prior @ C_COL)
    cl = defer_and_learn(sigma_M=sigma_M, erosion=erosion, prior=prior, grid=1501)["ev"]
    return np.array([a, b, c, cl])


# ---------------------------------------------------------------------------
# 8. Strategy: the entry game (Section 6.4)
# ---------------------------------------------------------------------------
GAME_M = np.array([[-25, 26], [-6, 18]])     # rows Full, Staged; cols Fight, Accommodate
GAME_I = np.array([[-10, -5], [-4, -2]])


def fight_threshold():
    """P(Fight) above which Staged beats Full for Meridian."""
    (f_f, f_a), (s_f, s_a) = GAME_M
    return (f_a - s_a) / ((f_a - s_a) + (s_f - f_f))


# ---------------------------------------------------------------------------
# 9. Monitoring: the tripwire's trade-off (Section 7.2)
# ---------------------------------------------------------------------------
def tripwire_rates(threshold):
    """P(fire | scenario) for a tripwire 'pilot share < threshold'."""
    return _norm_cdf((threshold - PILOT_MUS) / SIGMA)


def proceed_crossing():
    xs = np.linspace(0.04, 0.13, 20001)
    ev = (posterior(xs) * PROCEED).sum(axis=1)
    return float(xs[np.argmin(np.abs(ev))])


if __name__ == "__main__":
    np.set_printoptions(precision=2, suppress=True)
    print("A", A_COL, "B naive", B_NAIVE, "C", C_COL)
    sol = staged_policy()
    print("B strategy EV %.2f per %s P(go) %s cat %.3f thr %.4f" % (sol["ev"], sol["per"], sol["p_go"], sol["p_cat"], sol["threshold"]))
    print("EVSI/EVPI", evsi_evpi())
    print("fan indep", fan_stats(mc_independent()))
    v, _ = mc_correlated(); print("fan corr", fan_stats(v))
    for e in (0, .05, .10):
        d = defer_and_learn(erosion=e); print("C-learn e=%.2f EV %.2f per %s p_go %s cat %.4f" % (e, d["ev"], d["per"], d["p_go"], d["p_cat"]))
    print("fight threshold", fight_threshold())
    print("crossing", proceed_crossing(), "rates 6.5", tripwire_rates(0.065), "7.6", tripwire_rates(0.0762))
    print("perturb naive", weight_perturbation(SCORE_NAIVE)); print("perturb rev", weight_perturbation(SCORE_REVISED))


# ---------------------------------------------------------------------------
# 10. The native simulator: the single-story plan (Lab 0)
# ---------------------------------------------------------------------------
LAUNCH_TASKS = {            # median weeks, as the team imagines each task going
    "Distributor contract": 4, "Label approval": 3, "Packaging localisation": 3,
    "Warehouse set-up": 2, "Hiring city team": 4, "Retail listings": 4,
    "Launch marketing": 3, "First shipment": 3,
}


def plan_vs_world(n=100_000, seed=7, spread=0.5, shared=0.25):
    """Each task ~ lognormal around its median; a shared shock (one regulator, one
    distributor) moves all tasks together. Returns totals, the plan (sum of medians)."""
    rng = np.random.default_rng(seed)
    med = np.array(list(LAUNCH_TASKS.values()), float)
    common = rng.normal(0, shared, (n, 1))
    own = rng.normal(0, spread, (n, len(med)))
    totals = (med * np.exp(own + common)).sum(axis=1)
    return totals, float(med.sum())


# ---------------------------------------------------------------------------
# 11. Prediction is not intervention: the tasting-voucher experiment (Lab 2A)
# ---------------------------------------------------------------------------
def voucher_world(n=40_000, seed=21):
    """Home-market shoppers. loyalty in [0,1]. Baseline purchase rises with loyalty.
    The voucher's causal effect (uplift) is largest for the middle of the loyalty range,
    and slightly negative for the most loyal (they buy anyway; the voucher cheapens the brand)."""
    rng = np.random.default_rng(seed)
    loy = rng.beta(2, 2, n)
    p0 = 1 / (1 + np.exp(-(-2.2 + 4.4 * loy)))
    tau = 0.16 * np.exp(-((loy - 0.42) / 0.18) ** 2) - 0.04 * (loy > 0.80)
    # history: marketing gave vouchers mostly to loyal shoppers (confounding)
    p_hist = 1 / (1 + np.exp(-(-3 + 6 * loy)))
    t_hist = rng.random(n) < p_hist
    y_hist = rng.random(n) < np.clip(p0 + tau * t_hist, 0, 1)
    # experiment: vouchers assigned by coin flip
    t_rct = rng.random(n) < 0.5
    y_rct = rng.random(n) < np.clip(p0 + tau * t_rct, 0, 1)
    return dict(loy=loy, p0=p0, tau=tau, t_hist=t_hist, y_hist=y_hist, t_rct=t_rct, y_rct=y_rct)


def targeting_curves(w, margin=4.0, voucher_cost=0.25, bins=10):
    """Incremental profit from treating the top-k fraction ranked (i) by predicted purchase
    (the propensity model) and (ii) by experimentally estimated uplift by loyalty decile."""
    loy, rct_t, rct_y = w["loy"], w["t_rct"], w["y_rct"]
    edges = np.quantile(loy, np.linspace(0, 1, bins + 1))
    dec = np.clip(np.searchsorted(edges, loy, side="right") - 1, 0, bins - 1)
    up_hat = np.array([rct_y[(dec == d) & rct_t].mean() - rct_y[(dec == d) & ~rct_t].mean() for d in range(bins)])
    prop_hat = np.array([rct_y[(dec == d)].mean() for d in range(bins)])
    true_up = np.array([w["tau"][dec == d].mean() for d in range(bins)])
    frac = np.arange(0, bins + 1) / bins
    def curve(order):
        prof = [0.0]
        for k in range(1, bins + 1):
            chosen = order[:k]
            share = np.isin(dec, chosen).mean()
            gain = sum(true_up[d] * (dec == d).mean() for d in chosen) * margin
            prof.append(gain - share * voucher_cost)
        return np.array(prof)
    return dict(frac=frac, by_uplift=curve(np.argsort(-up_hat)), by_propensity=curve(np.argsort(-prop_hat)),
                random=frac * (w["tau"].mean() * margin - voucher_cost), up_hat=up_hat, prop_hat=prop_hat,
                true_up=true_up, dec_mid=(edges[:-1] + edges[1:]) / 2)


# ---------------------------------------------------------------------------
# 12. When the model meets a different world: drift (Lab 9A)
# ---------------------------------------------------------------------------
def drift_world(seed=9, months=60, shift_at=40):
    """Monthly pilot-city sales vs Meridian's price gap to the incumbent.
    Months 1-36 train the model. From month `shift_at` the incumbent starts matching
    promotions: the price-gap elasticity doubles and a new regime begins."""
    rng = np.random.default_rng(seed)
    t = np.arange(1, months + 1)
    gap = 0.15 + 0.05 * np.sin(t / 5) + rng.normal(0, 0.02, months)
    ramp = np.clip((t - shift_at) / 14, 0, 1)                    # the new regime phases in
    gap = gap + 0.06 * ramp                                         # incumbent undercuts
    beta = -20.0 - 20.0 * ramp                                      # customers grow more price-sensitive
    sales = 10 + beta * gap + 0.04 * t + rng.normal(0, 0.45, months)
    tr = t <= 36
    X = np.column_stack([np.ones(months), gap, t])
    coef, *_ = np.linalg.lstsq(X[tr], sales[tr], rcond=None)
    pred = X @ coef
    err = sales - pred
    sd = err[tr].std(ddof=3)
    # one-sided CUSUM on standardised under-forecast errors (sales below prediction)
    k, h = 0.5, 4.0
    c = np.zeros(months); alarm = None
    for i in range(36, months):
        c[i] = max(0.0, c[i - 1] + (-err[i] / sd) - k)
        if alarm is None and c[i] > h:
            alarm = int(t[i])
    # input check: share of months whose price gap lies outside the training range
    lo, hi = gap[tr].min(), gap[tr].max()
    outside = (gap < lo) | (gap > hi)
    return dict(t=t, gap=gap, sales=sales, pred=pred, err=err, sd=sd, cusum=c, h=h,
                alarm=alarm, outside=outside, shift_at=shift_at, train_range=(lo, hi))


# ---------------------------------------------------------------------------
# 13. When the organisation distorts the evidence: independent vs anchored estimates (Lab 15A)
# ---------------------------------------------------------------------------
def effective_n(n, rho):
    return n / (1 + (n - 1) * rho)


def estimate_rooms(truth=0.09, n_max=12, reps=20_000, sd=0.025, rho=0.3, pull=0.6, seed=15):
    """RMSE of the group's average estimate of steady-state share, by group size, for
    (i) fully independent estimates, (ii) estimates sharing a common error (same data,
    same consultant), (iii) an anchored meeting where each speaker moves `pull` of the
    way toward the first speaker before giving a number."""
    rng = np.random.default_rng(seed)
    out = {"independent": [], "shared": [], "anchored": []}
    ns = np.arange(1, n_max + 1)
    for n in ns:
        e = rng.normal(0, sd, (reps, n))
        ind = truth + e
        common = rng.normal(0, sd * np.sqrt(rho), (reps, 1))
        sh = truth + common + rng.normal(0, sd * np.sqrt(1 - rho), (reps, n))
        anc = sh.copy()
        anc[:, 1:] = pull * anc[:, [0]] + (1 - pull) * anc[:, 1:]
        for key, arr in (("independent", ind), ("shared", sh), ("anchored", anc)):
            out[key].append(float(np.sqrt(np.mean((arr.mean(axis=1) - truth) ** 2))))
    return ns, {k: np.array(v) for k, v in out.items()}
