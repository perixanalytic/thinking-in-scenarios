# Thinking in Scenarios — companion code

Code for **_Thinking in Scenarios: How to Use Evidence, Models, and AI to Make Better Decisions Under Uncertainty_** (PerixAnalytic, 2026) — [www.PerixAnalytic.com](https://www.PerixAnalytic.com).

Every number in the book's running case (Meridian Naturals) and every one of its thirty figures is produced by the code in this repository. Every random draw uses a fixed seed, so the results reproduce exactly.

## What is here

| Path | What it is |
|---|---|
| `Thinking_in_Scenarios_Labs.ipynb` | Every lab in reading order, with outputs saved. Self-contained: its first cells write `tis_core.py` and `tis_figures.py`, so the notebook alone is enough. |
| `tis_core.py` | The Meridian model and every analysis in one module: the driver model, Bayes, the decision tree solved exactly, defer-and-learn, the Monte Carlo runs, scorecards, robustness maps, the entry game, tripwires, and the simulations behind the new labs. |
| `tis_figures.py` | The figure kit. One function per figure in the book. `python tis_figures.py` redraws all thirty into `./figs`; `python tis_figures.py fan tornado` redraws two. |
| `labs/` | Each lab as a standalone script, named by lab number (`lab10a_value_of_waiting.py`). Each prints exactly the output shown in the book. |
| `figures/` | The book's figures as rendered (2160 px wide). |

## Quick start

```bash
pip install -r requirements.txt
jupyter notebook Thinking_in_Scenarios_Labs.ipynb     # run all cells
# or, without Jupyter:
python labs/lab10a_value_of_waiting.py
python tis_figures.py                                  # writes ./figs/*.png
```

Requires Python 3.10+ with NumPy, pandas, SciPy and Matplotlib. Charts use the Inter typeface if it is installed and fall back to Helvetica, Arial, or Matplotlib's default font otherwise.

## Using it on your own decision

Change the case specification in Section 1 of `tis_core.py` — market size, share, margin, fixed cost, ramp, the three scenarios and their prior — and rerun. Every lab and figure that depends on those assumptions recomputes.

## A note on what the code proves

Reproducible code establishes that a conclusion follows from its assumptions. It never establishes that the assumptions are true. The case is fictional; its numbers are teaching material, not market facts, and nothing here is financial or investment advice.
